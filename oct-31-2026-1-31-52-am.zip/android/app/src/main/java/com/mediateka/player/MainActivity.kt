package com.mediateka.player

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.mediateka.player.data.AppDatabase
import com.mediateka.player.data.TrackEntity
import com.mediateka.player.data.TrackRepository
import kotlinx.coroutines.launch
import com.mediateka.player.ui.theme.*

data class TrackItem(
    val id: Int,
    val title: String,
    val artist: String,
    val album: String,
    val durationSeconds: Int,
    val isFavorite: Boolean = false,
    val isDownloaded: Boolean = false
)

fun TrackEntity.toTrackItem(): TrackItem = TrackItem(
    id = id,
    title = title,
    artist = artist,
    album = album,
    durationSeconds = durationSeconds,
    isFavorite = isFavorite,
    isDownloaded = isDownloaded
)

val EaseEasing = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f)
val SpringEasing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MediatekaApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediatekaApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val database = remember { AppDatabase.getDatabase(context) }
    val repository = remember { TrackRepository(database.trackDao()) }

    var currentTab by remember { mutableStateOf("home") }
    var libraryInitialFilter by remember { mutableStateOf("Все") }
    var isPlaying by remember { mutableStateOf(false) }
    var currentTrackId by remember { mutableStateOf(1) }
    var showPlayerSheet by remember { mutableStateOf(false) }

    // Seed Room Database on first launch
    LaunchedEffect(Unit) {
        val initialList = listOf(
            TrackEntity(1, "1", "Вайбкод", "Ржавый бит", "Вайбкод EP", 160, isFavorite = true, isDownloaded = true),
            TrackEntity(2, "2", "teeth - slowed", "blair", "teeth single", 151, isFavorite = true, isDownloaded = true),
            TrackEntity(3, "3", "Дофамин", "YungMe...", "Дофамин", 101),
            TrackEntity(4, "4", "Дофамин 2", "YungMe...", "Дофамин", 90),
            TrackEntity(5, "5", "Белый 500", "Нурминский", "Дорога в никуда", 204),
            TrackEntity(6, "6", "Подъебал", "Слепой", "Single", 198),
            TrackEntity(7, "7", "Protoje-Who Knows", "Middle Eye", "Roots 2026", 212),
            TrackEntity(8, "8", "Quasimotion-Kevin", "Middle Eye", "The Unseen", 185),
            TrackEntity(9, "9", "Spirit", "Middle Eye", "Golden Era", 194),
            TrackEntity(10, "10", "Кукла колдуна", "Король и Шут", "Акустический альбом", 203, isFavorite = true),
            TrackEntity(11, "11", "Лесник", "Король и Шут", "Будь как дома, путник", 191),
            TrackEntity(12, "12", "Спокойная ночь", "Кино", "Группа крови", 367, isFavorite = true)
        )
        database.trackDao().insertTracks(initialList)
        repository.setQueue(listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12))
    }

    val dbTracks by repository.allTracks.collectAsState(initial = emptyList())
    val favTracks by repository.favoriteTracks.collectAsState(initial = emptyList())
    val dlTracks by repository.downloadedTracks.collectAsState(initial = emptyList())
    val queueIds by repository.playbackQueue.collectAsState()

    val sampleTracks = remember(dbTracks) {
        if (dbTracks.isNotEmpty()) dbTracks.map { it.toTrackItem() }
        else listOf(
            TrackItem(1, "Вайбкод", "Ржавый бит", "Вайбкод EP", 160, isFavorite = true, isDownloaded = true),
            TrackItem(2, "teeth - slowed", "blair", "teeth single", 151, isFavorite = true, isDownloaded = true),
            TrackItem(3, "Дофамин", "YungMe...", "Дофамин", 101),
            TrackItem(4, "Дофамин 2", "YungMe...", "Дофамин", 90),
            TrackItem(5, "Белый 500", "Нурминский", "Дорога в никуда", 204),
            TrackItem(6, "Подъебал", "Слепой", "Single", 198),
            TrackItem(7, "Protoje-Who Knows", "Middle Eye", "Roots 2026", 212),
            TrackItem(8, "Quasimotion-Kevin", "Middle Eye", "The Unseen", 185),
            TrackItem(9, "Spirit", "Middle Eye", "Golden Era", 194),
            TrackItem(10, "Кукла колдуна", "Король и Шут", "Акустический альбом", 203, isFavorite = true),
            TrackItem(11, "Лесник", "Король и Шут", "Будь как дома, путник", 191),
            TrackItem(12, "Спокойная ночь", "Кино", "Группа крови", 367, isFavorite = true)
        )
    }

    val currentTrack = sampleTracks.find { it.id == currentTrackId } ?: sampleTracks.firstOrNull()

    fun playNextTrack() {
        if (queueIds.isNotEmpty() && currentTrack != null) {
            val qIdx = queueIds.indexOf(currentTrack.id)
            val nextQIdx = if (qIdx != -1 && qIdx + 1 < queueIds.size) qIdx + 1 else 0
            currentTrackId = queueIds[nextQIdx]
        } else if (sampleTracks.isNotEmpty()) {
            val idx = sampleTracks.indexOfFirst { it.id == currentTrackId }
            val nextIdx = (idx + 1) % sampleTracks.size
            currentTrackId = sampleTracks[nextIdx].id
        }
        isPlaying = true
    }

    fun playPrevTrack() {
        if (queueIds.isNotEmpty() && currentTrack != null) {
            val qIdx = queueIds.indexOf(currentTrack.id)
            val prevQIdx = if (qIdx > 0) qIdx - 1 else queueIds.size - 1
            currentTrackId = queueIds[prevQIdx]
        } else if (sampleTracks.isNotEmpty()) {
            val idx = sampleTracks.indexOfFirst { it.id == currentTrackId }
            val prevIdx = if (idx > 0) idx - 1 else sampleTracks.size - 1
            currentTrackId = sampleTracks[prevIdx].id
        }
        isPlaying = true
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = VioletBg,
            surface = VioletSurface,
            primary = VioletPrimary,
            onPrimary = VioletOnPrimary,
            primaryContainer = VioletPrimaryContainer,
            onPrimaryContainer = VioletOnPrimaryContainer
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(VioletBg)
        ) {
            // Main content
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp)
                    .padding(top = 40.dp, bottom = 160.dp)
            ) {
                when (currentTab) {
                    "home" -> HomeScreenComposable(
                        tracks = sampleTracks,
                        currentTrack = currentTrack,
                        isPlaying = isPlaying,
                        favCount = favTracks.size,
                        dlCount = dlTracks.size,
                        onPlayTrack = { track ->
                            currentTrackId = track.id
                            isPlaying = true
                            repository.addToQueue(track.id)
                        },
                        onTogglePlay = { isPlaying = !isPlaying },
                        onNavigateToFilter = { filter ->
                            libraryInitialFilter = filter
                            currentTab = "lib"
                        }
                    )
                    "search" -> SearchScreenComposable(
                        tracks = sampleTracks,
                        onPlayTrack = { track ->
                            currentTrackId = track.id
                            isPlaying = true
                            repository.addToQueue(track.id)
                        }
                    )
                    "lib" -> LibraryScreenComposable(
                        tracks = sampleTracks,
                        initialFilter = libraryInitialFilter,
                        onPlayTrack = { track ->
                            currentTrackId = track.id
                            isPlaying = true
                            repository.addToQueue(track.id)
                        },
                        onToggleFav = { track ->
                            scope.launch { repository.toggleFavorite(track.id, track.isFavorite) }
                        },
                        onDownload = { track ->
                            scope.launch { repository.setDownloaded(track.id, true) }
                        },
                        onDeleteTrack = { track ->
                            scope.launch { repository.deleteTrack(track.id) }
                        }
                    )
                    "settings" -> SettingsScreenComposable()
                }
            }

            // Mini Player (above navigation bar)
            if (currentTrack != null) {
                MiniPlayerBar(
                    track = currentTrack,
                    isPlaying = isPlaying,
                    onTogglePlay = { isPlaying = !isPlaying },
                    onNext = { playNextTrack() },
                    onClick = { showPlayerSheet = true },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 88.dp, start = 14.dp, end = 14.dp)
                )
            }

            // Floating Navigation Pill
            FloatingNavBar(
                currentTab = currentTab,
                onSelectTab = { currentTab = it },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 16.dp)
            )

            // Fullscreen Bottom Sheet Player
            if (showPlayerSheet && currentTrack != null) {
                ModalBottomSheet(
                    onDismissRequest = { showPlayerSheet = false },
                    containerColor = VioletBg.copy(alpha = 0.95f),
                    shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
                ) {
                    PlayerSheetContent(
                        track = currentTrack,
                        isPlaying = isPlaying,
                        queueIds = queueIds,
                        allTracks = sampleTracks,
                        onTogglePlay = { isPlaying = !isPlaying },
                        onNext = { playNextTrack() },
                        onPrev = { playPrevTrack() },
                        onToggleFav = {
                            scope.launch { repository.toggleFavorite(currentTrack.id, currentTrack.isFavorite) }
                        },
                        onDownload = {
                            scope.launch { repository.setDownloaded(currentTrack.id, true) }
                        },
                        onPlayQueueItem = { trackId ->
                            currentTrackId = trackId
                            isPlaying = true
                        },
                        onRemoveQueueItem = { trackId ->
                            repository.removeFromQueue(trackId)
                        },
                        onClose = { showPlayerSheet = false }
                    )
                }
            }
        }
    }
}

@Composable
fun FloatingNavBar(
    currentTab: String,
    onSelectTab: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(36.dp),
        color = Color(0x8C3A3240),
        border = BorderStroke(1.dp, Color(0x1AFFFFFF)),
        shadowElevation = 12.dp
    ) {
        Row(
            modifier = Modifier.padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val tabs = listOf(
                Triple("home", "Главная", Icons.Default.Home),
                Triple("search", "Поиск", Icons.Default.Search),
                Triple("lib", "Медиатека", Icons.Default.LibraryMusic),
                Triple("settings", "Настройки", Icons.Default.Tune)
            )

            tabs.forEach { (key, label, icon) ->
                val selected = currentTab == key
                Surface(
                    onClick = { onSelectTab(key) },
                    shape = RoundedCornerShape(28.dp),
                    color = if (selected) VioletPrimaryContainer else Color.Transparent
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = if (selected) 16.dp else 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = if (selected) VioletOnPrimaryContainer else VioletMuted,
                            modifier = Modifier.size(24.dp)
                        )
                        if (selected) {
                            Text(
                                text = label,
                                color = VioletOnPrimaryContainer,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MiniPlayerBar(
    track: TrackItem,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(68.dp),
        shape = RoundedCornerShape(34.dp),
        color = VioletPrimaryContainer.copy(alpha = 0.85f),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(if (isPlaying) RoundedCornerShape(34) else CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(VioletPrimary.copy(alpha = 0.6f), VioletPrimaryContainer)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.MusicNote, contentDescription = null, tint = VioletPrimary)
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = VioletText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = track.artist,
                    fontSize = 12.sp,
                    color = VioletMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(
                onClick = onTogglePlay,
                modifier = Modifier
                    .size(48.dp)
                    .background(VioletPrimary, CircleShape)
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = VioletOnPrimary
                )
            }

            IconButton(onClick = onNext) {
                Icon(Icons.Default.SkipNext, contentDescription = null, tint = VioletText)
            }
        }
    }
}

@Composable
fun PlayerSheetContent(
    track: TrackItem,
    isPlaying: Boolean,
    queueIds: List<Int>,
    allTracks: List<TrackItem>,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onToggleFav: () -> Unit,
    onDownload: () -> Unit,
    onPlayQueueItem: (Int) -> Unit,
    onRemoveQueueItem: (Int) -> Unit,
    onClose: () -> Unit
) {
    var showQueue by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Свернуть", tint = VioletText)
            }
            Surface(
                onClick = { showQueue = !showQueue },
                shape = RoundedCornerShape(20.dp),
                color = if (showQueue) VioletPrimary else VioletSurface
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.QueueMusic, contentDescription = null, tint = if (showQueue) VioletOnPrimary else VioletMuted, modifier = Modifier.size(16.dp))
                    Text("Очередь (${queueIds.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (showQueue) VioletOnPrimary else VioletText)
                }
            }
            IconButton(onClick = {}) {
                Icon(Icons.Default.AutoAwesome, contentDescription = "Форма", tint = VioletText)
            }
        }

        if (showQueue) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp),
                shape = RoundedCornerShape(28.dp),
                color = VioletSurface.copy(alpha = 0.9f)
            ) {
                LazyColumn(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        Text("Очередь воспроизведения", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = VioletMuted)
                    }
                    val queueTracks = queueIds.mapNotNull { id -> allTracks.find { it.id == id } }
                    items(queueTracks) { qTrack ->
                        val isCurrent = qTrack.id == track.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isCurrent) VioletPrimary.copy(alpha = 0.25f) else Color.Transparent)
                                .clickable { onPlayQueueItem(qTrack.id) }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(VioletPrimaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = VioletPrimary, modifier = Modifier.size(20.dp))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(qTrack.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = if (isCurrent) VioletPrimary else VioletText, maxLines = 1)
                                Text(qTrack.artist, fontSize = 11.sp, color = VioletMuted, maxLines = 1)
                            }
                            if (isCurrent) {
                                Text("Играет", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VioletPrimary)
                            } else {
                                IconButton(onClick = { onRemoveQueueItem(qTrack.id) }, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Default.Close, contentDescription = "Убрать", tint = VioletMuted, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .background(
                        Brush.linearGradient(listOf(VioletPrimaryContainer, VioletSurface))
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(90.dp)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(track.title, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = VioletText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, color = VioletMuted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row {
                IconButton(onClick = onDownload) {
                    Icon(Icons.Default.Download, contentDescription = "Скачать", tint = if (track.isDownloaded) VioletPrimary else VioletMuted)
                }
                IconButton(onClick = onToggleFav) {
                    Icon(
                        imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Избранное",
                        tint = if (track.isFavorite) VioletPrimary else VioletMuted
                    )
                }
            }
        }

        // Wave Seek bar
        Slider(
            value = 0.35f,
            onValueChange = {},
            colors = SliderDefaults.colors(
                thumbColor = VioletPrimary,
                activeTrackColor = VioletPrimary,
                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
            )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("1:05", fontSize = 12.sp, color = VioletMuted)
            Text("${track.durationSeconds / 60}:${(track.durationSeconds % 60).toString().padStart(2, '0')}", fontSize = 12.sp, color = VioletMuted)
        }

        // Volume row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Default.VolumeUp, contentDescription = "Громкость", tint = VioletMuted)
            Slider(
                value = 0.85f,
                onValueChange = {},
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(
                    thumbColor = VioletPrimary,
                    activeTrackColor = VioletPrimary,
                    inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                )
            )
            Text("85%", fontSize = 12.sp, color = VioletMuted)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {}) {
                Icon(Icons.Default.Shuffle, contentDescription = null, tint = VioletMuted)
            }
            IconButton(onClick = onPrev) {
                Icon(Icons.Default.SkipPrevious, contentDescription = null, tint = VioletText, modifier = Modifier.size(32.dp))
            }
            IconButton(
                onClick = onTogglePlay,
                modifier = Modifier
                    .size(72.dp)
                    .background(VioletPrimary, CircleShape)
            ) {
                Icon(
                    if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = VioletOnPrimary,
                    modifier = Modifier.size(36.dp)
                )
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Default.SkipNext, contentDescription = null, tint = VioletText, modifier = Modifier.size(32.dp))
            }
            IconButton(onClick = {}) {
                Icon(Icons.Default.Repeat, contentDescription = null, tint = VioletMuted)
            }
        }
    }
}

@Composable
fun HomeScreenComposable(
    tracks: List<TrackItem>,
    currentTrack: TrackItem?,
    isPlaying: Boolean,
    favCount: Int,
    dlCount: Int,
    onPlayTrack: (TrackItem) -> Unit,
    onTogglePlay: () -> Unit,
    onNavigateToFilter: (String) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(18.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "MD3 Player",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = VioletText
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = {},
                        modifier = Modifier
                            .size(46.dp)
                            .background(VioletSurface, CircleShape)
                    ) {
                        Icon(Icons.Default.Folder, contentDescription = "Папка", tint = VioletText)
                    }
                    IconButton(
                        onClick = {},
                        modifier = Modifier
                            .size(46.dp)
                            .background(VioletSurface, CircleShape)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Файлы", tint = VioletText)
                    }
                }
            }
        }

        item {
            Column {
                Text(
                    text = "Ваша подборка",
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Bold,
                    color = VioletText,
                    lineHeight = 42.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = currentTrack?.let { "${it.artist} - ${it.title}" } ?: "Ржавый бит - Вайбкод",
                            fontSize = 14.sp,
                            color = VioletMuted
                        )
                        Button(
                            onClick = onTogglePlay,
                            colors = ButtonDefaults.buttonColors(containerColor = VioletPrimary, contentColor = VioletOnPrimary),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Мой микс", fontWeight = FontWeight.Bold)
                        }
                    }

                    Box {
                        IconButton(
                            onClick = onTogglePlay,
                            modifier = Modifier
                                .size(96.dp)
                                .background(VioletPrimaryContainer, CircleShape)
                        ) {
                            Icon(
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = VioletOnPrimaryContainer,
                                modifier = Modifier.size(44.dp)
                            )
                        }
                        IconButton(
                            onClick = { tracks.randomOrNull()?.let { onPlayTrack(it) } },
                            modifier = Modifier
                                .size(46.dp)
                                .align(Alignment.BottomEnd)
                                .background(VioletPrimary, CircleShape)
                                .border(4.dp, VioletBg, CircleShape)
                        ) {
                            Icon(Icons.Default.Casino, contentDescription = null, tint = VioletOnPrimary, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }

        // Bento Grid: Вперемешку, Избранное, Загрузки
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Left Big Tile: Вперемешку
                Surface(
                    onClick = { tracks.randomOrNull()?.let { onPlayTrack(it) } },
                    modifier = Modifier
                        .weight(1.25f)
                        .fillMaxHeight(),
                    shape = RoundedCornerShape(topStart = 36.dp, topEnd = 14.dp, bottomStart = 36.dp, bottomEnd = 14.dp),
                    color = VioletPrimary
                ) {
                    Box(modifier = Modifier.padding(16.dp)) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = VioletOnPrimary, modifier = Modifier.size(28.dp))
                        Column(modifier = Modifier.align(Alignment.BottomStart)) {
                            Text("Вперемешку", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = VioletOnPrimary)
                            Text("Случайные треки", fontSize = 12.sp, color = VioletOnPrimary.copy(alpha = 0.8f))
                        }
                    }
                }

                // Right Column: Избранное & Загрузки
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Top Tile: Избранное
                    Surface(
                        onClick = { onNavigateToFilter("Избранное") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        shape = RoundedCornerShape(topStart = 14.dp, topEnd = 36.dp, bottomStart = 14.dp, bottomEnd = 14.dp),
                        color = Color(0xFF382E3E)
                    ) {
                        Box(modifier = Modifier.padding(14.dp)) {
                            Icon(Icons.Default.Favorite, contentDescription = null, tint = VioletPrimary, modifier = Modifier.align(Alignment.TopEnd).size(22.dp))
                            Column(modifier = Modifier.align(Alignment.BottomStart)) {
                                Text("Избранное", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = VioletText)
                                Text("$favCount трека", fontSize = 11.sp, color = VioletMuted)
                            }
                        }
                    }

                    // Bottom Tile: Загрузки
                    Surface(
                        onClick = { onNavigateToFilter("Загрузки") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        shape = RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp, bottomStart = 36.dp, bottomEnd = 14.dp),
                        color = VioletPrimaryContainer
                    ) {
                        Box(modifier = Modifier.padding(14.dp)) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = VioletOnPrimaryContainer, modifier = Modifier.align(Alignment.TopEnd).size(22.dp))
                            Column(modifier = Modifier.align(Alignment.BottomStart)) {
                                Text("Загрузки", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = VioletOnPrimaryContainer)
                                Text("$dlCount треков", fontSize = 11.sp, color = VioletOnPrimaryContainer.copy(alpha = 0.75f))
                            }
                        }
                    }
                }
            }
        }

        item {
            Text("Рекомендации", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = VioletText)
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(tracks.take(6)) { track ->
                    Column(
                        modifier = Modifier
                            .width(150.dp)
                            .clickable { onPlayTrack(track) }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(150.dp)
                                .clip(RoundedCornerShape(26.dp))
                                .background(Brush.linearGradient(listOf(VioletPrimaryContainer, VioletSurface))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color.White.copy(alpha = 0.6f))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(track.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, color = VioletText)
                        Text(track.artist, fontSize = 12.sp, color = VioletMuted, maxLines = 1)
                    }
                }
            }
        }

        item {
            Text("Все треки • ${tracks.size}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = VioletText)
        }

        items(tracks) { track ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onPlayTrack(track) }
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Brush.linearGradient(listOf(VioletPrimaryContainer, VioletSurface))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color.White.copy(alpha = 0.6f))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(track.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = VioletText)
                    Text(track.artist, fontSize = 12.sp, color = VioletMuted)
                }
                Text("${track.durationSeconds / 60}:${(track.durationSeconds % 60).toString().padStart(2, '0')}", fontSize = 12.sp, color = VioletMuted)
            }
        }
    }
}

@Composable
fun SearchScreenComposable(tracks: List<TrackItem>, onPlayTrack: (TrackItem) -> Unit) {
    var query by remember { mutableStateOf("") }
    val recent = listOf("назад в кресты", "пошел ты нахуй старый год", "яйца", "под новый год", "подъебал", "нурминский")

    val filteredTracks = remember(query, tracks) {
        if (query.isBlank()) emptyList()
        else tracks.filter {
            it.title.contains(query, ignoreCase = true) ||
            it.artist.contains(query, ignoreCase = true) ||
            it.album.contains(query, ignoreCase = true)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Поиск", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = VioletText)

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Песни, исполнители, ссылка YouTube", color = VioletMuted) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = VioletPrimary) },
            shape = RoundedCornerShape(32.dp),
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = VioletPrimary,
                unfocusedBorderColor = VioletPrimary.copy(alpha = 0.5f),
                focusedContainerColor = VioletSurface,
                unfocusedContainerColor = VioletSurface
            )
        )

        if (filteredTracks.isNotEmpty()) {
            Text("Результаты • ${filteredTracks.size}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = VioletMuted)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f, fill = false)) {
                items(filteredTracks) { track ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPlayTrack(track) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(VioletPrimaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.MusicNote, contentDescription = null, tint = VioletPrimary)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(track.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = VioletText)
                            Text(track.artist, fontSize = 12.sp, color = VioletMuted)
                        }
                        Text("${track.durationSeconds / 60}:${(track.durationSeconds % 60).toString().padStart(2, '0')}", fontSize = 12.sp, color = VioletMuted)
                    }
                }
            }
        } else {
            Text("Недавние запросы", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = VioletMuted)
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                recent.forEach { item ->
                    Surface(
                        onClick = { query = item },
                        shape = RoundedCornerShape(16.dp),
                        color = VioletSurface
                    ) {
                        Text(item, color = VioletText, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun LibraryScreenComposable(
    tracks: List<TrackItem>,
    initialFilter: String = "Все",
    onPlayTrack: (TrackItem) -> Unit,
    onToggleFav: (TrackItem) -> Unit,
    onDownload: (TrackItem) -> Unit,
    onDeleteTrack: (TrackItem) -> Unit
) {
    var selectedFilter by remember { mutableStateOf(initialFilter) }
    val filters = listOf("Все", "Избранное", "Артисты", "Альбомы", "Загрузки")

    val displayedTracks = remember(selectedFilter, tracks) {
        when (selectedFilter) {
            "Избранное" -> tracks.filter { it.isFavorite }
            "Загрузки" -> tracks.filter { it.isDownloaded }
            else -> tracks
        }
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxSize()) {
        item {
            Text("Медиатека", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = VioletText)
        }

        item {
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                filters.forEach { filter ->
                    val active = selectedFilter == filter
                    Surface(
                        onClick = { selectedFilter = filter },
                        shape = RoundedCornerShape(20.dp),
                        color = if (active) VioletPrimary else VioletSurface
                    ) {
                        Text(
                            filter,
                            color = if (active) VioletOnPrimary else VioletMuted,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = VioletSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .background(VioletPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = VioletOnPrimary)
                    }
                    Column {
                        Text("Добавить музыку", fontWeight = FontWeight.Bold, color = VioletText, fontSize = 16.sp)
                        Text("${tracks.size} треков, хранятся на устройстве", color = VioletMuted, fontSize = 12.sp)
                    }
                }
            }
        }

        item {
            Text(
                text = "$selectedFilter • ${displayedTracks.size}",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = VioletText
            )
        }

        if (displayedTracks.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Пока пусто", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = VioletText)
                        Text(
                            if (selectedFilter == "Избранное") "Добавьте треки в избранное кнопкой сердечка"
                            else "Скачанные треки будут отображаться здесь",
                            color = VioletMuted,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        } else {
            items(displayedTracks) { track ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .clickable { onPlayTrack(track) }
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Brush.linearGradient(listOf(VioletPrimaryContainer, VioletSurface))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color.White.copy(alpha = 0.6f))
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(track.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = VioletText, maxLines = 1)
                        Text(track.artist, fontSize = 12.sp, color = VioletMuted, maxLines = 1)
                    }
                    IconButton(onClick = { onDownload(track) }) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Скачать",
                            tint = if (track.isDownloaded) VioletPrimary else VioletMuted
                        )
                    }
                    IconButton(onClick = { onToggleFav(track) }) {
                        Icon(
                            imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Избранное",
                            tint = if (track.isFavorite) VioletPrimary else VioletMuted
                        )
                    }
                    IconButton(onClick = { onDeleteTrack(track) }) {
                        Icon(Icons.Default.Close, contentDescription = "Удалить", tint = VioletMuted)
                    }
                    Text("${track.durationSeconds / 60}:${(track.durationSeconds % 60).toString().padStart(2, '0')}", fontSize = 12.sp, color = VioletMuted)
                }
            }
        }
    }
}

@Composable
fun SettingsScreenComposable() {
    var activeTab by remember { mutableStateOf("Вид") }
    val tabs = listOf("Вид", "Фон", "Лента", "Сервисы")

    Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Настройки", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = VioletText)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(VioletSurface, RoundedCornerShape(16.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            tabs.forEach { tab ->
                val active = activeTab == tab
                Surface(
                    onClick = { activeTab = tab },
                    shape = RoundedCornerShape(12.dp),
                    color = if (active) VioletPrimary else Color.Transparent,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        tab,
                        color = if (active) VioletOnPrimary else VioletMuted,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .padding(vertical = 10.dp)
                            .wrapContentWidth(Alignment.CenterHorizontally)
                    )
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(28.dp),
            color = VioletSurface.copy(alpha = 0.7f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Тема", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = VioletText)
                Text("На выбор 9 тем оформления: Фиалка, Роза, Океан, Мята, Закат, AMOLED, Моно, Моно AMOLED, Светлая.", color = VioletMuted, fontSize = 13.sp)
            }
        }
    }
}
