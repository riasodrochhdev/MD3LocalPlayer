package com.mediateka.player.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val key: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationSeconds: Int,
    val hue: Int = 280,
    val isFavorite: Boolean = false,
    val isDownloaded: Boolean = false,
    val localUri: String? = null,
    val addedAt: Long = System.currentTimeMillis()
)
