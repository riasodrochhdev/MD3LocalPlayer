package com.mediateka.player.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class TrackRepository(private val trackDao: TrackDao) {
    val allTracks: Flow<List<TrackEntity>> = trackDao.getAllTracks()
    val favoriteTracks: Flow<List<TrackEntity>> = trackDao.getFavoriteTracks()
    val downloadedTracks: Flow<List<TrackEntity>> = trackDao.getDownloadedTracks()
    val favoriteCount: Flow<Int> = trackDao.getFavoriteCount()
    val downloadedCount: Flow<Int> = trackDao.getDownloadedCount()

    // In-memory active playback queue
    private val _playbackQueue = MutableStateFlow<List<Int>>(emptyList())
    val playbackQueue: StateFlow<List<Int>> = _playbackQueue.asStateFlow()

    fun setQueue(trackIds: List<Int>) {
        _playbackQueue.value = trackIds
    }

    fun addToQueue(trackId: Int) {
        if (!_playbackQueue.value.contains(trackId)) {
            _playbackQueue.value = _playbackQueue.value + trackId
        }
    }

    fun playNext(currentTrackId: Int, newTrackId: Int) {
        val currentList = _playbackQueue.value.toMutableList()
        currentList.remove(newTrackId)
        val currentIndex = currentList.indexOf(currentTrackId)
        val insertIndex = if (currentIndex >= 0) currentIndex + 1 else 0
        currentList.add(insertIndex, newTrackId)
        _playbackQueue.value = currentList
    }

    fun removeFromQueue(trackId: Int) {
        _playbackQueue.value = _playbackQueue.value.filter { it != trackId }
    }

    suspend fun toggleFavorite(id: Int, currentFav: Boolean) {
        trackDao.setFavorite(id, !currentFav)
    }

    suspend fun setDownloaded(id: Int, isDownloaded: Boolean) {
        trackDao.setDownloaded(id, isDownloaded)
    }

    suspend fun insertTrack(track: TrackEntity): Long {
        return trackDao.insertTrack(track)
    }

    suspend fun deleteTrack(id: Int) {
        trackDao.deleteTrackById(id)
        removeFromQueue(id)
    }
}
