import React, { useState, useEffect, useRef } from 'react';
import { storage } from './utils/storage.ts';
import {
  Track,
  ThemeName,
  getNextTrackIndex,
  parseAudioFileName,
  addToQueue,
  playNextInQueue,
  removeFromQueue,
} from './utils/player.ts';
import { INITIAL_TRACKS } from './data/mockTracks.ts';
import { audioEngine } from './utils/audioEngine.ts';
import { FloatingNav, NavTab } from './components/FloatingNav.tsx';
import { MiniPlayer } from './components/MiniPlayer.tsx';
import { PlayerSheet } from './components/PlayerSheet.tsx';
import { TrackContextMenu } from './components/TrackContextMenu.tsx';
import { SnowEffect } from './components/SnowEffect.tsx';
import { HomeScreen } from './screens/HomeScreen.tsx';
import { SearchScreen } from './screens/SearchScreen.tsx';
import { LibraryScreen } from './screens/LibraryScreen.tsx';
import { SettingsScreen } from './screens/SettingsScreen.tsx';

export default function App() {
  const [tracks, setTracks] = useState<Track[]>(() => {
    const savedCustom = storage.getCustomTracks();
    const favSet = storage.getFavorites();
    const dlSet = storage.getDownloads();
    const base = [...savedCustom, ...INITIAL_TRACKS];
    return base.map((t) => ({
      ...t,
      isFav: favSet.has(t.id),
      isDownloaded: dlSet.has(t.id) || t.isDownloaded || false,
    }));
  });

  const [queue, setQueue] = useState<number[]>(() => {
    const saved = storage.getQueue();
    if (saved && saved.length > 0) return saved;
    return INITIAL_TRACKS.map((t) => t.id);
  });

  const [currentTabIndex, setCurrentTab] = useState<NavTab>('home');
  const [libraryFilter, setLibraryFilter] = useState<'all' | 'fav' | 'artists' | 'albums' | 'dl'>('all');
  const [selectedArtist, setSelectedArtist] = useState<string | null>(null);

  // Playback state
  const [currentTrackIndex, setCurrentTrackIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(160);
  const [volume, setVolume] = useState<number>(0.9);
  const [isShuffle, setIsShuffle] = useState<boolean>(false);
  const [repeatMode, setRepeatMode] = useState<number>(0); // 0 = off, 1 = all, 2 = one

  // Sheet & Dialog states
  const [isPlayerSheetOpen, setIsPlayerSheetOpen] = useState<boolean>(false);
  const [contextMenuTrack, setContextMenuTrack] = useState<Track | null>(null);

  // Settings states
  const [theme, setTheme] = useState<ThemeName>('violet');
  const [glassMode, setGlassMode] = useState<'off' | 'blur' | 'liquid'>('liquid');
  const [snowEnabled, setSnowEnabled] = useState<boolean>(false);
  const [favIconStyle, setFavIconStyle] = useState<'plus' | 'heart'>('plus');
  const [hapticEnabled, setHapticEnabled] = useState<boolean>(true);
  const [motionMode, setMotionMode] = useState<'full' | 'system' | 'reduced'>('full');

  // File input refs for local files and folders
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement | null>(null);

  const currentTrack = tracks[currentTrackIndex] || tracks[0] || null;

  // Persist favorites, downloads, and custom tracks whenever tracks change
  useEffect(() => {
    const favSet = new Set(tracks.filter((t) => t.isFav).map((t) => t.id));
    storage.saveFavorites(favSet);

    const dlSet = new Set(tracks.filter((t) => t.isDownloaded).map((t) => t.id));
    storage.saveDownloads(dlSet);

    const customTracks = tracks.filter((t) => t.id > 100);
    storage.saveCustomTracks(customTracks);
  }, [tracks]);

  // Persist queue whenever it changes
  useEffect(() => {
    storage.saveQueue(queue);
  }, [queue]);

  // Apply theme, glass mode and motion mode to document root
  useEffect(() => {
    document.documentElement.dataset.theme = theme === 'violet' ? '' : theme;
  }, [theme]);

  useEffect(() => {
    document.documentElement.dataset.glass = glassMode;
  }, [glassMode]);

  useEffect(() => {
    document.documentElement.dataset.motion = motionMode;
  }, [motionMode]);

  // Connect AudioEngine listeners
  useEffect(() => {
    const unbindPlayback = audioEngine.addPlaybackListener((playing) => {
      setIsPlaying(playing);
    });

    const unbindTime = audioEngine.addTimeListener((curr, dur) => {
      setCurrentTime(curr);
      if (dur > 0) setDuration(dur);
    });

    const unbindEnd = audioEngine.addEndListener(() => {
      handleNextTrack();
    });

    audioEngine.setNavigationHandlers(
      () => handleNextTrack(),
      () => handlePrevTrack()
    );

    return () => {
      unbindPlayback();
      unbindTime();
      unbindEnd();
    };
  }, [currentTrackIndex, tracks, queue, isShuffle, repeatMode]);

  // Update MediaSession and initial track load
  useEffect(() => {
    if (currentTrack) {
      setDuration(currentTrack.dur || 160);
      audioEngine.updateMediaSession(currentTrack);
    }
  }, [currentTrackIndex]);

  // Haptic feedback trigger
  const triggerHaptic = () => {
    if (hapticEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(10);
      } catch (_) {}
    }
  };

  const handlePlayTrack = (track: Track) => {
    triggerHaptic();
    const idx = tracks.findIndex((t) => t.id === track.id);
    if (idx !== -1) {
      setCurrentTrackIndex(idx);
      setCurrentTime(0);
      audioEngine.loadTrack(track, true);

      // Ensure playing track is in queue
      if (!queue.includes(track.id)) {
        setQueue((prev) => [track.id, ...prev]);
      }
    }
  };

  const handlePlayTrackById = (trackId: number) => {
    const target = tracks.find((t) => t.id === trackId);
    if (target) {
      handlePlayTrack(target);
    }
  };

  const handleTogglePlay = () => {
    triggerHaptic();
    if (!currentTrack) return;
    if (isPlaying) {
      audioEngine.pause();
    } else {
      if (!audioEngine.isCurrentlyPlaying() && audioEngine.getCurrentTime() === 0) {
        audioEngine.loadTrack(currentTrack, true);
      } else {
        audioEngine.play();
      }
    }
  };

  const handleNextTrack = () => {
    triggerHaptic();
    if (queue.length > 0 && currentTrack) {
      const qIdx = queue.indexOf(currentTrack.id);
      const nextQIdx = getNextTrackIndex(
        qIdx !== -1 ? qIdx : 0,
        queue.length,
        isShuffle,
        repeatMode
      );
      if (nextQIdx !== -1) {
        const nextId = queue[nextQIdx];
        const nextTrack = tracks.find((t) => t.id === nextId);
        if (nextTrack) {
          const idx = tracks.findIndex((t) => t.id === nextTrack.id);
          setCurrentTrackIndex(idx !== -1 ? idx : 0);
          setCurrentTime(0);
          audioEngine.loadTrack(nextTrack, true);
          return;
        }
      }
    }

    const nextIdx = getNextTrackIndex(currentTrackIndex, tracks.length, isShuffle, repeatMode);
    if (nextIdx !== -1 && tracks[nextIdx]) {
      setCurrentTrackIndex(nextIdx);
      setCurrentTime(0);
      audioEngine.loadTrack(tracks[nextIdx], true);
    } else {
      audioEngine.pause();
    }
  };

  const handlePrevTrack = () => {
    triggerHaptic();
    if (currentTime > 3) {
      audioEngine.seek(0);
      setCurrentTime(0);
      return;
    }

    if (queue.length > 0 && currentTrack) {
      const qIdx = queue.indexOf(currentTrack.id);
      const prevQIdx = qIdx > 0 ? qIdx - 1 : queue.length - 1;
      const prevId = queue[prevQIdx];
      const prevTrack = tracks.find((t) => t.id === prevId);
      if (prevTrack) {
        const idx = tracks.findIndex((t) => t.id === prevTrack.id);
        setCurrentTrackIndex(idx !== -1 ? idx : 0);
        setCurrentTime(0);
        audioEngine.loadTrack(prevTrack, true);
        return;
      }
    }

    const prevIdx = currentTrackIndex > 0 ? currentTrackIndex - 1 : tracks.length - 1;
    if (tracks[prevIdx]) {
      setCurrentTrackIndex(prevIdx);
      setCurrentTime(0);
      audioEngine.loadTrack(tracks[prevIdx], true);
    }
  };

  const handleSeek = (seconds: number) => {
    setCurrentTime(seconds);
    audioEngine.seek(seconds);
  };

  const handleVolumeChange = (newVolume: number) => {
    setVolume(newVolume);
    audioEngine.setVolume(newVolume);
  };

  const handleToggleShuffle = () => {
    triggerHaptic();
    setIsShuffle((prev) => !prev);
  };

  const handleToggleRepeat = () => {
    triggerHaptic();
    setRepeatMode((prev) => (prev + 1) % 3);
  };

  const handleRandomTrack = () => {
    triggerHaptic();
    const randomIdx = Math.floor(Math.random() * tracks.length);
    if (tracks[randomIdx]) {
      handlePlayTrack(tracks[randomIdx]);
    }
  };

  const handleShuffleAll = () => {
    triggerHaptic();
    const shuffled = [...tracks].sort(() => Math.random() - 0.5);
    const newQueue = shuffled.map((t) => t.id);
    setQueue(newQueue);
    if (shuffled[0]) {
      handlePlayTrack(shuffled[0]);
    }
  };

  const handleToggleFav = (track: Track) => {
    triggerHaptic();
    setTracks((prev) =>
      prev.map((t) => (t.id === track.id ? { ...t, isFav: !t.isFav } : t))
    );
  };

  const handleDownload = (track: Track) => {
    triggerHaptic();
    setTracks((prev) =>
      prev.map((t) => (t.id === track.id ? { ...t, isDownloaded: true } : t))
    );
  };

  const handleDeleteTrack = (track: Track) => {
    triggerHaptic();
    if (confirm(`Удалить «${track.title}» из медиатеки?`)) {
      if (currentTrack?.id === track.id) {
        audioEngine.pause();
      }
      setTracks((prev) => prev.filter((t) => t.id !== track.id));
      setQueue((prev) => prev.filter((id) => id !== track.id));
    }
  };

  const handlePlayNext = (track: Track) => {
    triggerHaptic();
    if (!currentTrack) return;
    setQueue((prev) => playNextInQueue(prev, prev.indexOf(currentTrack.id), track.id));
  };

  const handleAddToQueue = (track: Track) => {
    triggerHaptic();
    setQueue((prev) => addToQueue(prev, track.id));
  };

  const handleRemoveFromQueue = (trackId: number) => {
    triggerHaptic();
    setQueue((prev) => removeFromQueue(prev, trackId));
  };

  const handleOpenArtist = (artist: string) => {
    setSelectedArtist(artist);
    setCurrentTab('lib');
  };

  const handleFilterLib = (filter: 'fav' | 'dl') => {
    setSelectedArtist(null);
    setLibraryFilter(filter);
    setCurrentTab('lib');
  };

  // Local File & Folder Loading
  const handleFilesSelected = (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;

    const newTracks: Track[] = [];
    let startId = Date.now();

    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      if (
        !/^audio\//.test(file.type) &&
        !/\.(mp3|m4a|flac|wav|ogg|opus|aac|weba)$/i.test(file.name)
      ) {
        continue;
      }

      const { title, artist } = parseAudioFileName(file.name);
      const relativePath = (file as any).webkitRelativePath || '';
      const pathParts = relativePath.split('/');
      const album = pathParts.length > 1 ? pathParts[pathParts.length - 2] : 'Локальные файлы';

      const objectUrl = URL.createObjectURL(file);
      const track: Track = {
        id: ++startId,
        key: `local-${file.name}-${file.size}`,
        title,
        artist,
        album,
        dur: 0,
        hue: 260 + (title.charCodeAt(0) % 80),
        isDownloaded: true,
        isFav: false,
      };
      (track as any).url = objectUrl;

      // Extract duration via temporary Audio object
      const probeAudio = new Audio();
      probeAudio.preload = 'metadata';
      probeAudio.onloadedmetadata = () => {
        if (probeAudio.duration > 0) {
          track.dur = Math.round(probeAudio.duration);
          setTracks((prev) =>
            prev.map((t) => (t.id === track.id ? { ...t, dur: track.dur } : t))
          );
        }
      };
      probeAudio.src = objectUrl;

      newTracks.push(track);
    }

    if (newTracks.length > 0) {
      const newIds = newTracks.map((t) => t.id);
      setTracks((prev) => [...newTracks, ...prev]);
      setQueue((prev) => [...newIds, ...prev]);
      // Immediately start playing the first added track
      setCurrentTrackIndex(0);
      setCurrentTime(0);
      audioEngine.loadTrack(newTracks[0], true);
    }
  };

  const handleTriggerPickFiles = () => {
    fileInputRef.current?.click();
  };

  const handleTriggerPickFolder = () => {
    folderInputRef.current?.click();
  };

  return (
    <div className="relative min-h-screen bg-[var(--bg)] text-[var(--tx)] selection:bg-[var(--p)] selection:text-[var(--onp)]">
      {/* Hidden File & Folder Inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept="audio/*,.mp3,.m4a,.flac,.wav,.ogg,.opus,.aac,.weba"
        multiple
        className="hidden"
        onChange={(e) => {
          handleFilesSelected(e.target.files);
          e.target.value = '';
        }}
      />
      <input
        ref={folderInputRef}
        type="file"
        // @ts-ignore
        webkitdirectory=""
        directory=""
        multiple
        className="hidden"
        onChange={(e) => {
          handleFilesSelected(e.target.files);
          e.target.value = '';
        }}
      />

      {/* Ambient Radial Mesh Background */}
      <div className="amb" aria-hidden="true" />

      {/* Snow Falling Canvas */}
      <SnowEffect enabled={snowEnabled} />

      {/* Mobile-first Max Width Centered Shell */}
      <main className="max-w-[540px] mx-auto px-5 pt-7">
        {/* Android Status Bar Simulation */}
        <div className="flex items-center justify-between text-xs text-[var(--tx)] font-semibold tracking-tight pb-3 select-none opacity-90">
          <span>00:40</span>
          <div className="flex items-center gap-1.5 text-[11px]">
            <span>VPN</span>
            <span>4G</span>
            <span>39%</span>
          </div>
        </div>

        {/* Tab 1: Главная */}
        {currentTabIndex === 'home' && (
          <HomeScreen
            tracks={tracks}
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            favCount={tracks.filter((t) => t.isFav).length}
            downloadedCount={tracks.filter((t) => t.isDownloaded).length}
            favIconStyle={favIconStyle}
            onPlayTrack={handlePlayTrack}
            onTogglePlay={handleTogglePlay}
            onRandomTrack={handleRandomTrack}
            onMyMix={handleRandomTrack}
            onToggleFav={handleToggleFav}
            onDownload={handleDownload}
            onOpenContextMenu={(t) => setContextMenuTrack(t)}
            onNavigateTab={(tab) => setCurrentTab(tab)}
            onFilterLib={handleFilterLib}
            onOpenArtist={handleOpenArtist}
            onPickFiles={handleTriggerPickFiles}
            onPickFolder={handleTriggerPickFolder}
          />
        )}

        {/* Tab 2: Поиск */}
        {currentTabIndex === 'search' && (
          <SearchScreen
            tracks={tracks}
            currentTrack={currentTrack}
            favIconStyle={favIconStyle}
            onPlayTrack={handlePlayTrack}
            onToggleFav={handleToggleFav}
            onDownload={handleDownload}
            onOpenContextMenu={(t) => setContextMenuTrack(t)}
            onOpenArtist={handleOpenArtist}
          />
        )}

        {/* Tab 3: Медиатека */}
        {currentTabIndex === 'lib' && (
          <LibraryScreen
            tracks={tracks}
            currentTrack={currentTrack}
            activeFilter={libraryFilter}
            selectedArtist={selectedArtist}
            favIconStyle={favIconStyle}
            onFilterChange={(f) => {
              setSelectedArtist(null);
              setLibraryFilter(f);
            }}
            onSelectArtist={(a) => setSelectedArtist(a)}
            onPlayTrack={handlePlayTrack}
            onTogglePlay={handleTogglePlay}
            onToggleFav={handleToggleFav}
            onDownload={handleDownload}
            onDeleteTrack={handleDeleteTrack}
            onOpenContextMenu={(t) => setContextMenuTrack(t)}
            onShuffleAll={handleShuffleAll}
            onPickFiles={handleTriggerPickFiles}
            onPickFolder={handleTriggerPickFolder}
          />
        )}

        {/* Tab 4: Настройки */}
        {currentTabIndex === 'settings' && (
          <SettingsScreen
            currentTheme={theme}
            onSelectTheme={(th) => {
              triggerHaptic();
              setTheme(th);
            }}
            glassMode={glassMode}
            onChangeGlassMode={(gm) => {
              triggerHaptic();
              setGlassMode(gm);
            }}
            snowEnabled={snowEnabled}
            onToggleSnow={() => {
              triggerHaptic();
              setSnowEnabled((prev) => !prev);
            }}
            favIconStyle={favIconStyle}
            onChangeFavIconStyle={(style) => {
              triggerHaptic();
              setFavIconStyle(style);
            }}
            hapticEnabled={hapticEnabled}
            onToggleHaptic={() => setHapticEnabled((prev) => !prev)}
            motionMode={motionMode}
            onToggleMotion={() => {
              triggerHaptic();
              setMotionMode((prev) =>
                prev === 'full' ? 'reduced' : prev === 'reduced' ? 'system' : 'full'
              );
            }}
          />
        )}
      </main>

      {/* Mini Player */}
      <div className="max-w-[540px] mx-auto">
        <MiniPlayer
          track={currentTrack}
          isPlaying={isPlaying}
          progress={duration > 0 ? currentTime / duration : 0}
          currentTime={currentTime}
          duration={duration}
          onTogglePlay={(e) => {
            e.stopPropagation();
            handleTogglePlay();
          }}
          onNext={(e) => {
            e.stopPropagation();
            handleNextTrack();
          }}
          onOpenSheet={() => setIsPlayerSheetOpen(true)}
        />
      </div>

      {/* Floating Bottom Nav */}
      <FloatingNav
        currentTab={currentTabIndex}
        onSelectTab={(tab) => {
          triggerHaptic();
          if (tab !== 'lib') setSelectedArtist(null);
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Fullscreen Player Sheet with Volume, Seeking & Active Queue */}
      <PlayerSheet
        isOpen={isPlayerSheetOpen}
        track={currentTrack}
        isPlaying={isPlaying}
        currentTime={currentTime}
        duration={duration}
        volume={volume}
        isShuffle={isShuffle}
        repeatMode={repeatMode}
        favIconStyle={favIconStyle}
        queue={queue}
        allTracks={tracks}
        onClose={() => setIsPlayerSheetOpen(false)}
        onTogglePlay={handleTogglePlay}
        onNext={handleNextTrack}
        onPrev={handlePrevTrack}
        onToggleShuffle={handleToggleShuffle}
        onToggleRepeat={handleToggleRepeat}
        onToggleFav={handleToggleFav}
        onDownload={handleDownload}
        onSeek={handleSeek}
        onVolumeChange={handleVolumeChange}
        onPlayTrackById={handlePlayTrackById}
        onRemoveFromQueue={handleRemoveFromQueue}
      />

      {/* Track Context Menu on Long Press */}
      <TrackContextMenu
        track={contextMenuTrack}
        isOpen={contextMenuTrack !== null}
        onClose={() => setContextMenuTrack(null)}
        onPlayNext={handlePlayNext}
        onAddToQueue={handleAddToQueue}
        onToggleFav={handleToggleFav}
        onDownload={handleDownload}
        onGoToArtist={handleOpenArtist}
        onDelete={handleDeleteTrack}
      />
    </div>
  );
}
