import React from 'react';
import { Icon } from './Icons.tsx';

interface CoverArtProps {
  hue?: number;
  title?: string;
  artist?: string;
  shape?: 'squircle' | 'round' | 'star';
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  className?: string;
}

export const CoverArt: React.FC<CoverArtProps> = ({
  hue = 280,
  title = '',
  shape = 'squircle',
  size = 'md',
  className = '',
}) => {
  const dynamicHue = hue || 270 + (title ? [...title].reduce((acc, c) => acc + c.charCodeAt(0), 0) % 80 : 0);

  const sizeClasses = {
    sm: 'w-10 h-10 min-w-10 min-h-10 text-sm',
    md: 'w-12 h-12 min-w-12 min-h-12 text-base',
    lg: 'w-36 h-36 min-w-36 min-h-36',
    xl: 'w-48 h-48 min-w-48 min-h-48',
    full: 'w-full aspect-square',
  }[size];

  const shapeClasses = {
    squircle: 'rounded-[28px]',
    round: 'rounded-full',
    star: 'rounded-[35%] transition-all duration-500',
  }[shape];

  return (
    <div
      className={`relative flex items-center justify-center shrink-0 shadow-md select-none overflow-hidden ${sizeClasses} ${shapeClasses} ${className}`}
      style={{
        background: `linear-gradient(145deg, hsl(${dynamicHue}, 45%, 38%), hsl(${dynamicHue + 40}, 48%, 22%))`,
        color: 'rgba(255, 255, 255, 0.75)',
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-tr from-black/25 via-transparent to-white/15 pointer-events-none" />
      <Icon name="note" size={size === 'sm' ? 20 : size === 'md' ? 24 : size === 'lg' ? 44 : 64} />
    </div>
  );
};
