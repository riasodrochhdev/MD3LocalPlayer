import React from 'react';
import { Icon } from './Icons.tsx';

export type NavTab = 'home' | 'search' | 'lib' | 'settings';

interface FloatingNavProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
}

export const FloatingNav: React.FC<FloatingNavProps> = ({ currentTab, onSelectTab }) => {
  const tabs: { id: NavTab; label: string; icon: string }[] = [
    { id: 'home', label: 'Главная', icon: 'home' },
    { id: 'search', label: 'Поиск', icon: 'search' },
    { id: 'lib', label: 'Медиатека', icon: 'lib' },
    { id: 'settings', label: 'Настройки', icon: 'tune' },
  ];

  return (
    <nav
      id="nav"
      className="fixed z-30 left-1/2 bottom-[14px] flex items-center gap-1 p-2 rounded-full glass shadow-2xl anim-dock-in select-none"
      aria-label="Основная навигация"
    >
      {tabs.map((tab) => {
        const isActive = currentTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onSelectTab(tab.id)}
            aria-label={tab.label}
            className={`h-14 flex items-center justify-center gap-0 px-4 rounded-full nav-btn-active font-semibold cursor-pointer overflow-hidden ${
              isActive
                ? 'bg-[var(--pc)] text-[var(--onpc)] shadow-md pl-4 pr-5'
                : 'text-[var(--mu)] hover:text-[var(--tx)] hover:bg-[var(--hv)]'
            }`}
          >
            <Icon name={tab.icon} size={24} />
            <span
              className={`overflow-hidden whitespace-nowrap text-sm font-semibold transition-[max-width,opacity,margin] duration-400 ease-[cubic-bezier(0.2,0.8,0.2,1)] ${
                isActive ? 'max-w-[120px] opacity-100 ml-2' : 'max-w-0 opacity-0 ml-0'
              }`}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
