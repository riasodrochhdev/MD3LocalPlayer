import React from 'react';
import { Track } from '../utils/player.ts';
import { Icon } from './Icons.tsx';

interface MiniPlayerProps {
  track: Track | null;
  isPlaying: boolean;
  progress: number; // 0 to 1
  currentTime: number;
  duration: number;
  onTogglePlay: (e: React.MouseEvent) => void;
  onNext: (e: React.MouseEvent) => void;
  onOpenSheet: () => void;
}

export const MiniPlayer: React.FC<MiniPlayerProps> = ({
  track,
  isPlaying,
  progress,
  onTogglePlay,
  onNext,
  onOpenSheet,
}) => {
  if (!track) return null;

  return (
    <div
      onClick={onOpenSheet}
      className="fixed z-20 left-3 right-3 bottom-[88px] h-[68px] px-3 py-2 rounded-[34px] flex items-center gap-3 glass bg-[color-mix(in_srgb,var(--pc)_75%,transparent)] text-[var(--onpc)] shadow-xl cursor-pointer select-none overflow-hidden row-ease-active mini-player-in"
      aria-label="Мини-плеер"
    >
      {/* Background progress fill */}
      <div
        className="absolute inset-y-0 left-0 bg-[color-mix(in_srgb,var(--p)_18%,transparent)] pointer-events-none transition-all duration-300 ease-[cubic-bezier(0.2,0.8,0.2,1)]"
        style={{ width: `${Math.min(100, Math.max(0, progress * 100))}%` }}
      />

      {/* Album Cover with morphing border radius */}
      <div
        className={`relative w-[52px] h-[52px] rounded-full shrink-0 flex items-center justify-center transition-[border-radius] duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)] overflow-hidden ${
          isPlaying ? 'rounded-[36%]' : 'rounded-full'
        }`}
        style={{
          background: `linear-gradient(145deg, hsl(${track.hue || 280}, 45%, 36%), hsl(${(track.hue || 280) + 40}, 48%, 20%))`,
          border: '3px solid color-mix(in srgb, var(--p) 45%, transparent)',
          color: 'var(--p)',
        }}
      >
        <Icon name="note" size={24} />
      </div>

      {/* Track Info */}
      <div className="relative flex-1 min-w-0 flex flex-col justify-center">
        <b className="font-semibold text-[15px] truncate text-[var(--tx)]">{track.title}</b>
        <small className="text-xs text-[var(--mu)] truncate">{track.artist}</small>
      </div>

      {/* Controls */}
      <div className="relative flex items-center gap-2 shrink-0" onClick={(e) => e.stopPropagation()}>
        <button
          onClick={onTogglePlay}
          aria-label={isPlaying ? 'Пауза' : 'Воспроизвести'}
          className={`w-[54px] h-[54px] flex items-center justify-center rounded-full bg-[var(--p)] text-[var(--onp)] shadow-md play-btn-active cursor-pointer ${
            isPlaying ? 'rounded-[35%]' : 'rounded-full'
          }`}
        >
          <Icon name={isPlaying ? 'pause' : 'play'} size={24} />
        </button>

        <button
          onClick={onNext}
          aria-label="Следующий трек"
          className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white/10 btn-spring-active text-[var(--tx)] cursor-pointer"
        >
          <Icon name="next" size={22} />
        </button>
      </div>
    </div>
  );
};
