import React, { useState } from 'react';
import { Track, formatTime } from '../utils/player.ts';
import { Icon } from './Icons.tsx';
import { CoverArt } from './CoverArt.tsx';

interface PlayerSheetProps {
  isOpen: boolean;
  track: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isShuffle: boolean;
  repeatMode: number; // 0 = off, 1 = all, 2 = one
  favIconStyle: 'plus' | 'heart';
  queue: number[];
  allTracks: Track[];
  onClose: () => void;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev: () => void;
  onToggleShuffle: () => void;
  onToggleRepeat: () => void;
  onToggleFav: (track: Track) => void;
  onDownload: (track: Track) => void;
  onSeek: (seconds: number) => void;
  onVolumeChange: (volume: number) => void;
  onPlayTrackById: (id: number) => void;
  onRemoveFromQueue: (id: number) => void;
}

export const PlayerSheet: React.FC<PlayerSheetProps> = ({
  isOpen,
  track,
  isPlaying,
  currentTime,
  duration,
  volume,
  isShuffle,
  repeatMode,
  favIconStyle,
  queue,
  allTracks,
  onClose,
  onTogglePlay,
  onNext,
  onPrev,
  onToggleShuffle,
  onToggleRepeat,
  onToggleFav,
  onDownload,
  onSeek,
  onVolumeChange,
  onPlayTrackById,
  onRemoveFromQueue,
}) => {
  const [coverShapeIndex, setCoverShapeIndex] = useState<number>(0); // 0 = squircle, 1 = circle, 2 = star
  const [isSeeking, setIsSeeking] = useState(false);
  const [showQueue, setShowQueue] = useState(false);

  if (!track) return null;

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;
  const isFav = track.isFav ?? false;

  const handleCycleShape = () => {
    setCoverShapeIndex((prev) => (prev + 1) % 3);
  };

  const getCoverShapeClass = () => {
    if (coverShapeIndex === 1) {
      return `rounded-full ${isPlaying ? 'anim-spin-24s' : ''}`;
    }
    if (coverShapeIndex === 2) {
      return `rounded-[40%_25%_40%_25%] shadow-none ${isPlaying ? 'anim-spin-24s' : ''}`;
    }
    return isPlaying ? 'rounded-[32%]' : 'rounded-[15%]';
  };

  const queueTracks = queue.map((id) => allTracks.find((t) => t.id === id)).filter(Boolean) as Track[];

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col justify-between px-6 pt-10 pb-8 bg-[color-mix(in_srgb,var(--bg)_82%,transparent)] backdrop-blur-2xl transition-all duration-500 ease-[cubic-bezier(0.2,0.8,0.2,1)] overflow-hidden ${
        isOpen
          ? 'translate-y-0 opacity-100 pointer-events-auto'
          : 'translate-y-full opacity-0 pointer-events-none'
      }`}
      role="dialog"
      aria-label="Полноэкранный плеер"
    >
      {/* Drifting ambient spots: slow 20s drift, pauses when music is paused */}
      <div
        className={`absolute inset-[-25%] -z-10 pointer-events-none opacity-40 blur-3xl transition-opacity duration-700 anim-drift ${
          isPlaying ? '' : '[animation-play-state:paused]'
        }`}
        style={{
          background: `radial-gradient(40% 40% at 28% 30%, hsl(${track.hue || 290}, 55%, 42%, 0.5), transparent), radial-gradient(45% 45% at 76% 74%, hsl(${(track.hue || 290) + 50}, 55%, 38%, 0.45), transparent)`,
        }}
      />

      {/* Header bar with Queue toggle */}
      <div className="flex items-center justify-between w-full max-w-[460px] mx-auto">
        <button
          onClick={onClose}
          aria-label="Свернуть плеер"
          className="w-12 h-12 rounded-full flex items-center justify-center glass btn-spring-active text-[var(--tx)] cursor-pointer"
        >
          <Icon name="down" size={24} />
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowQueue(!showQueue)}
            aria-label="Очередь воспроизведения"
            className={`h-9 px-3 rounded-full flex items-center gap-1.5 text-xs font-semibold chip-spring-active cursor-pointer ${
              showQueue
                ? 'bg-[var(--p)] text-[var(--onp)] shadow-md'
                : 'glass text-[var(--tx)] hover:bg-white/10'
            }`}
          >
            <Icon name="queue" size={16} />
            <span>Очередь ({queue.length})</span>
          </button>
        </div>

        <button
          onClick={handleCycleShape}
          aria-label="Форма обложки"
          className="w-12 h-12 rounded-full flex items-center justify-center glass btn-spring-active text-[var(--tx)] cursor-pointer"
        >
          <Icon name="shape" size={22} />
        </button>
      </div>

      {/* Center content: Cover Art OR Queue View */}
      <div className="flex flex-col items-center justify-center my-auto w-full max-w-[460px] mx-auto overflow-hidden">
        {showQueue ? (
          <div className="w-full h-[320px] rounded-3xl glass p-4 flex flex-col gap-2 overflow-y-auto no-scrollbar anim-screen-in">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <span className="text-xs uppercase tracking-wider font-bold text-[var(--mu)]">
                Очередь воспроизведения
              </span>
              <span className="text-xs text-[var(--p)] font-semibold">
                {queueTracks.length} треков
              </span>
            </div>

            <div className="space-y-1 pt-1">
              {queueTracks.map((qTrack, idx) => {
                const isCurrent = qTrack.id === track.id;
                return (
                  <div
                    key={`${qTrack.id}-${idx}`}
                    onClick={() => onPlayTrackById(qTrack.id)}
                    className={`flex items-center gap-3 p-2 rounded-2xl cursor-pointer hover:bg-white/5 active:scale-[0.99] transition-all ${
                      isCurrent ? 'bg-[color-mix(in_srgb,var(--pc)_65%,transparent)]' : ''
                    }`}
                  >
                    <CoverArt hue={qTrack.hue} title={qTrack.title} size="sm" className="w-10 h-10 rounded-xl" />
                    <div className="min-w-0 flex-1">
                      <b className={`block text-sm truncate ${isCurrent ? 'text-[var(--p)] font-bold' : 'text-[var(--tx)]'}`}>
                        {qTrack.title}
                      </b>
                      <small className="block text-xs text-[var(--mu)] truncate">
                        {qTrack.artist}
                      </small>
                    </div>

                    {isCurrent ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[var(--p)] text-[var(--onp)] shrink-0">
                        Играет
                      </span>
                    ) : (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onRemoveFromQueue(qTrack.id);
                        }}
                        aria-label="Убрать из очереди"
                        className="w-8 h-8 rounded-full flex items-center justify-center text-[var(--mu)] hover:text-rose-400 btn-spring-active"
                      >
                        <Icon name="x" size={16} />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div
            key={track.id}
            className={`relative w-[min(72vw,300px)] aspect-square flex items-center justify-center shadow-2xl transition-[border-radius,transform] duration-500 ease-[cubic-bezier(0.2,0.8,0.2,1)] select-none overflow-hidden ${getCoverShapeClass()}`}
            style={{
              background: `linear-gradient(145deg, hsl(${track.hue || 280}, 45%, 42%), hsl(${(track.hue || 280) + 40}, 48%, 22%))`,
              boxShadow: '0 24px 60px rgba(0, 0, 0, 0.55)',
              color: 'rgba(255, 255, 255, 0.7)',
            }}
          >
            <Icon name="note" size={96} />
          </div>
        )}
      </div>

      {/* Track Info & Actions */}
      <div className="w-full max-w-[460px] mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <div className="min-w-0 pr-4">
            <h2 className="text-2xl font-bold font-display truncate text-[var(--tx)] tracking-tight">
              {track.title}
            </h2>
            <p className="text-base text-[var(--mu)] truncate mt-0.5">{track.artist}</p>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={() => onDownload(track)}
              aria-label="Скачать трек"
              className={`w-11 h-11 rounded-full flex items-center justify-center btn-spring-active cursor-pointer ${
                track.isDownloaded ? 'text-[var(--p)]' : 'text-[var(--tx)] hover:bg-white/10'
              }`}
            >
              <Icon name={track.isDownloaded ? 'check' : 'dl'} size={22} />
            </button>

            <button
              onClick={() => onToggleFav(track)}
              aria-label="В избранное"
              className={`w-11 h-11 rounded-full flex items-center justify-center btn-spring-active cursor-pointer ${
                isFav
                  ? favIconStyle === 'heart'
                    ? 'text-[var(--te)]'
                    : 'bg-[color-mix(in_srgb,var(--p)_20%,transparent)] text-[var(--p)]'
                  : 'text-[var(--tx)] hover:bg-white/10'
              }`}
            >
              <Icon
                name={
                  favIconStyle === 'heart'
                    ? isFav
                      ? 'heart'
                      : 'heart'
                    : isFav
                    ? 'check'
                    : 'plus'
                }
                size={22}
              />
            </button>
          </div>
        </div>

        {/* Wavy seek bar: linear wave run when playing, flat when paused, thumb expansion on seek */}
        <div className="space-y-1.5">
          <div className="relative h-9 flex items-center cursor-pointer select-none">
            {/* Background inactive track */}
            <div className="absolute inset-x-0 h-1 bg-white/20 rounded-full overflow-hidden">
              <div
                className="h-full bg-white/20"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            {/* Active wave / flat line with 0.5s ease transition */}
            <div
              className="absolute left-0 top-1/2 -translate-y-1/2 h-4 overflow-hidden pointer-events-none rounded-l-full"
              style={{ width: `${Math.max(0, progressPercent)}%` }}
            >
              <div
                className={`w-[2000px] h-full ${
                  isPlaying ? 'wv-wave-running' : 'wv-wave-flat'
                }`}
              />
            </div>

            {/* Vertical Pill Thumb (30px standard, 38px when active/seeking with spring) */}
            <div
              className={`absolute top-1/2 -translate-y-1/2 rounded-full bg-[var(--p)] shadow-md pointer-events-none seek-thumb ${
                isSeeking ? 'w-1 h-[38px] -translate-x-[2px]' : 'w-1.5 h-[30px] -translate-x-[3px]'
              }`}
              style={{ left: `${progressPercent}%` }}
            />

            {/* Hidden native range input for accessible touch/click drag */}
            <input
              type="range"
              min="0"
              max={duration || 100}
              value={currentTime}
              onMouseDown={() => setIsSeeking(true)}
              onMouseUp={() => setIsSeeking(false)}
              onTouchStart={() => setIsSeeking(true)}
              onTouchEnd={() => setIsSeeking(false)}
              onChange={(e) => onSeek(Number(e.target.value))}
              aria-label="Полоса перемотки"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
            />
          </div>

          <div className="flex justify-between text-xs font-mono text-[var(--mu)] tabular-nums">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Main Controls Row */}
        <div className="flex items-center justify-between pt-1 pb-1">
          <button
            onClick={onToggleShuffle}
            aria-label="Перемешать треки"
            className={`w-12 h-12 rounded-full flex items-center justify-center btn-spring-active cursor-pointer ${
              isShuffle ? 'text-[var(--p)] bg-[color-mix(in_srgb,var(--p)_16%,transparent)]' : 'text-[var(--mu)] hover:text-[var(--tx)]'
            }`}
          >
            <Icon name="shuffle" size={24} />
          </button>

          <button
            onClick={onPrev}
            aria-label="Предыдущий трек"
            className="w-12 h-12 rounded-full flex items-center justify-center text-[var(--tx)] hover:bg-white/10 btn-spring-active cursor-pointer"
          >
            <Icon name="prev" size={26} />
          </button>

          {/* Big Play/Pause Button: 0.88 scale on active */}
          <button
            onClick={onTogglePlay}
            aria-label={isPlaying ? 'Пауза' : 'Воспроизвести'}
            className={`w-[76px] h-[76px] flex items-center justify-center rounded-full bg-[var(--p)] text-[var(--onp)] shadow-2xl play-btn-active cursor-pointer ${
              isPlaying ? 'rounded-[35%]' : 'rounded-full'
            }`}
          >
            <Icon name={isPlaying ? 'pause' : 'play'} size={34} />
          </button>

          <button
            onClick={onNext}
            aria-label="Следующий трек"
            className="w-12 h-12 rounded-full flex items-center justify-center text-[var(--tx)] hover:bg-white/10 btn-spring-active cursor-pointer"
          >
            <Icon name="next" size={26} />
          </button>

          <button
            onClick={onToggleRepeat}
            aria-label="Повтор"
            className={`relative w-12 h-12 rounded-full flex items-center justify-center btn-spring-active cursor-pointer ${
              repeatMode > 0
                ? 'text-[var(--p)] bg-[color-mix(in_srgb,var(--p)_16%,transparent)]'
                : 'text-[var(--mu)] hover:text-[var(--tx)]'
            }`}
          >
            <Icon name="repeat" size={24} />
            {repeatMode === 2 && (
              <span className="absolute text-[10px] font-bold text-[var(--p)] top-2 right-2">
                1
              </span>
            )}
          </button>
        </div>

        {/* Volume Slider Row */}
        <div className="flex items-center gap-3 px-2 pt-1 pb-3">
          <button
            onClick={() => onVolumeChange(volume > 0 ? 0 : 0.8)}
            aria-label="Глушить звук"
            className="text-[var(--mu)] hover:text-[var(--tx)] btn-spring-active"
          >
            <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor">
              <path d="M3 9v6h4l5 5V4L7 9z" />
            </svg>
          </button>
          <div className="relative flex-1 flex items-center h-6">
            <div className="w-full h-1.5 bg-white/15 rounded-full overflow-hidden">
              <div
                className="h-full bg-[var(--p)] transition-all duration-75"
                style={{ width: `${Math.round(volume * 100)}%` }}
              />
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={volume}
              onChange={(e) => onVolumeChange(Number(e.target.value))}
              aria-label="Громкость"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
          </div>
          <span className="text-xs font-mono text-[var(--mu)] w-8 text-right tabular-nums">
            {Math.round(volume * 100)}%
          </span>
        </div>
      </div>
    </div>
  );
};
