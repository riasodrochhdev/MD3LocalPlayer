import React, { useEffect, useRef } from 'react';

interface SnowEffectProps {
  enabled: boolean;
  density?: number; // 1 = light, 2 = medium, 3 = heavy
}

export const SnowEffect: React.FC<SnowEffectProps> = ({ enabled, density = 2 }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!enabled) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    const count = [0, 25, 55, 95][density] || 55;
    const flakes = Array.from({ length: count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      r: 1.5 + Math.random() * 2.8,
      vy: 20 + Math.random() * 30,
      sw: 8 + Math.random() * 15,
      p: Math.random() * Math.PI * 2,
      opacity: 0.35 + Math.random() * 0.45,
    }));

    let lastTime = performance.now();

    const render = (time: number) => {
      const dt = Math.min(0.05, (time - lastTime) / 1000);
      lastTime = time;

      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';

      for (const flake of flakes) {
        flake.y += flake.vy * dt;
        flake.p += dt * 1.5;
        const currentX = flake.x + Math.sin(flake.p) * flake.sw;

        if (flake.y > height + 10) {
          flake.y = -10;
          flake.x = Math.random() * width;
        }

        ctx.fillStyle = `rgba(255, 255, 255, ${flake.opacity})`;
        ctx.beginPath();
        ctx.arc(currentX, flake.y, flake.r, 0, Math.PI * 2);
        ctx.fill();
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
    };
  }, [enabled, density]);

  if (!enabled) return null;

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none z-40"
      aria-hidden="true"
    />
  );
};
