import React from 'react';
import { Track } from '../utils/player.ts';
import { Icon } from './Icons.tsx';

interface TrackContextMenuProps {
  track: Track | null;
  isOpen: boolean;
  onClose: () => void;
  onPlayNext: (track: Track) => void;
  onAddToQueue: (track: Track) => void;
  onToggleFav: (track: Track) => void;
  onDownload: (track: Track) => void;
  onGoToArtist: (artist: string) => void;
  onDelete: (track: Track) => void;
}

export const TrackContextMenu: React.FC<TrackContextMenuProps> = ({
  track,
  isOpen,
  onClose,
  onPlayNext,
  onAddToQueue,
  onToggleFav,
  onDownload,
  onGoToArtist,
  onDelete,
}) => {
  if (!track || !isOpen) return null;

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-sm animate-fadeIn"
      role="dialog"
      aria-label="Меню трека"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-[500px] mx-auto bg-[color-mix(in_srgb,var(--s1)_94%,var(--bg))] rounded-t-[32px] p-4 pb-8 shadow-2xl border-t border-white/10 animate-slideUp"
      >
        {/* Track header */}
        <div className="flex items-center gap-3.5 pb-3 border-b border-white/10 mb-2">
          <div
            className="w-13 h-13 rounded-2xl flex items-center justify-center shrink-0 shadow-md"
            style={{
              background: `linear-gradient(145deg, hsl(${track.hue || 280}, 45%, 38%), hsl(${(track.hue || 280) + 40}, 48%, 22%))`,
              color: 'rgba(255, 255, 255, 0.7)',
            }}
          >
            <Icon name="note" size={26} />
          </div>
          <div className="min-w-0 flex-1">
            <b className="block text-base font-semibold truncate text-[var(--tx)]">
              {track.title}
            </b>
            <small className="block text-sm text-[var(--mu)] truncate mt-0.5">
              {track.artist}
            </small>
          </div>
        </div>

        {/* Action items */}
        <div className="space-y-1">
          <button
            onClick={() => {
              onPlayNext(track);
              onClose();
            }}
            className="w-full h-13 px-4 rounded-2xl flex items-center gap-4 text-left font-medium text-[var(--tx)] hover:bg-white/10 active:scale-[0.98] transition-all cursor-pointer"
          >
            <span className="text-[var(--p)]">
              <Icon name="play" size={22} />
            </span>
            <span>Играть следующим</span>
          </button>

          <button
            onClick={() => {
              onAddToQueue(track);
              onClose();
            }}
            className="w-full h-13 px-4 rounded-2xl flex items-center gap-4 text-left font-medium text-[var(--tx)] hover:bg-white/10 active:scale-[0.98] transition-all cursor-pointer"
          >
            <span className="text-[var(--p)]">
              <Icon name="queue" size={22} />
            </span>
            <span>Добавить в очередь</span>
          </button>

          <button
            onClick={() => {
              onToggleFav(track);
              onClose();
            }}
            className="w-full h-13 px-4 rounded-2xl flex items-center gap-4 text-left font-medium text-[var(--tx)] hover:bg-white/10 active:scale-[0.98] transition-all cursor-pointer"
          >
            <span className="text-[var(--p)]">
              <Icon name={track.isFav ? 'check' : 'plus'} size={22} />
            </span>
            <span>{track.isFav ? 'Убрать из избранного' : 'В избранное'}</span>
          </button>

          <button
            onClick={() => {
              onDownload(track);
              onClose();
            }}
            className="w-full h-13 px-4 rounded-2xl flex items-center gap-4 text-left font-medium text-[var(--tx)] hover:bg-white/10 active:scale-[0.98] transition-all cursor-pointer"
          >
            <span className="text-[var(--p)]">
              <Icon name="dl" size={22} />
            </span>
            <span>{track.isDownloaded ? 'Уже скачано' : 'Скачать'}</span>
          </button>

          <button
            onClick={() => {
              onGoToArtist(track.artist);
              onClose();
            }}
            className="w-full h-13 px-4 rounded-2xl flex items-center gap-4 text-left font-medium text-[var(--tx)] hover:bg-white/10 active:scale-[0.98] transition-all cursor-pointer"
          >
            <span className="text-[var(--p)]">
              <Icon name="user" size={22} />
            </span>
            <span>К исполнителю</span>
          </button>

          <button
            onClick={() => {
              onDelete(track);
              onClose();
            }}
            className="w-full h-13 px-4 rounded-2xl flex items-center gap-4 text-left font-medium text-rose-400 hover:bg-rose-500/10 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Icon name="del" size={22} />
            <span>Удалить из медиатеки</span>
          </button>
        </div>
      </div>
    </div>
  );
};
