import React from 'react';
import { Track } from '../utils/player.ts';
import { Icon, LogoBadge } from '../components/Icons.tsx';
import { CoverArt } from '../components/CoverArt.tsx';

interface HomeScreenProps {
  tracks: Track[];
  currentTrack: Track | null;
  isPlaying: boolean;
  favCount: number;
  downloadedCount: number;
  favIconStyle: 'plus' | 'heart';
  onPlayTrack: (track: Track) => void;
  onTogglePlay: () => void;
  onRandomTrack: () => void;
  onMyMix: () => void;
  onToggleFav: (track: Track) => void;
  onDownload: (track: Track) => void;
  onOpenContextMenu: (track: Track) => void;
  onNavigateTab: (tab: 'lib' | 'settings') => void;
  onFilterLib: (filter: 'fav' | 'dl') => void;
  onOpenArtist: (artist: string) => void;
  onPickFiles: () => void;
  onPickFolder: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  tracks,
  currentTrack,
  isPlaying,
  favCount,
  downloadedCount,
  favIconStyle,
  onPlayTrack,
  onTogglePlay,
  onRandomTrack,
  onMyMix,
  onToggleFav,
  onDownload,
  onOpenContextMenu,
  onNavigateTab,
  onFilterLib,
  onOpenArtist,
  onPickFiles,
  onPickFolder,
}) => {
  const heroSubtitle = currentTrack
    ? `${currentTrack.artist} - ${currentTrack.title}`
    : 'Ржавый бит - Вайбкод';

  const recommendations = tracks.slice(6, 12);
  const favoriteTracks = tracks.filter((t) => t.isFav);

  return (
    <div className="space-y-7 pb-36 anim-screen-in">
      {/* Top Bar */}
      <div className="flex items-center gap-3">
        <LogoBadge size={54} />
        <h2 className="text-2xl font-bold font-display tracking-tight flex-1 text-[var(--tx)]">
          MD3 Player
        </h2>

        <button
          onClick={onPickFolder}
          title="Добавить папку"
          aria-label="Добавить папку"
          className="w-12 h-12 rounded-full flex items-center justify-center glass btn-spring-active text-[var(--tx)] cursor-pointer"
        >
          <Icon name="folder" size={22} />
        </button>

        <button
          onClick={onPickFiles}
          title="Добавить файлы"
          aria-label="Добавить файлы"
          className="w-12 h-12 rounded-full flex items-center justify-center glass btn-spring-active text-[var(--tx)] cursor-pointer"
        >
          <Icon name="plus" size={22} />
        </button>
      </div>

      {/* Hero Section */}
      <div className="relative pt-2">
        <h1 className="text-[clamp(2.4rem,10vw,4.8rem)] font-bold font-display leading-[1.04] tracking-tight text-[var(--tx)]">
          Ваша подборка
        </h1>

        <div className="flex items-center justify-between mt-3">
          <div className="space-y-3 max-w-[65%]">
            <p className="text-[var(--mu)] text-base truncate font-medium">{heroSubtitle}</p>

            <button
              onClick={onMyMix}
              className="inline-flex items-center gap-2 h-12 px-6 rounded-full bg-[var(--p)] text-[var(--onp)] font-semibold shadow-md btn-spring-active cursor-pointer"
            >
              <Icon name="sparkle" size={20} />
              <span>Мой микс</span>
            </button>
          </div>

          {/* Big Play FAB & Dice */}
          <div className="relative shrink-0">
            <button
              onClick={onTogglePlay}
              aria-label={isPlaying ? 'Пауза' : 'Воспроизвести'}
              className={`w-[100px] h-[100px] rounded-full flex items-center justify-center bg-[var(--pc)] text-[var(--onpc)] shadow-xl fab-play-active cursor-pointer ${
                isPlaying ? 'anim-blob' : 'rounded-full'
              }`}
            >
              <Icon name={isPlaying ? 'pause' : 'play'} size={40} />
            </button>

            <button
              onClick={onRandomTrack}
              title="Случайный трек"
              aria-label="Случайный трек"
              className="absolute -right-2 -bottom-2 w-[52px] h-[52px] rounded-full bg-[var(--p)] text-[var(--onp)] flex items-center justify-center border-4 border-[var(--bg)] shadow-md btn-dice cursor-pointer"
            >
              <Icon name="dice" size={24} />
            </button>
          </div>
        </div>
      </div>

      {/* Bento Grid */}
      <div className="grid grid-cols-[1.25fr_1fr] grid-rows-[86px_86px] gap-2.5">
        {/* Left Big Tile */}
        <button
          onClick={onRandomTrack}
          className="relative row-span-2 p-4 flex flex-col justify-end text-left rounded-[40px_14px_40px_14px] bg-[var(--p)] text-[var(--onp)] shadow-md overflow-hidden card-hoverable btn-spring-active cursor-pointer group anim-rise"
          style={{ animationDelay: '0.04s' }}
        >
          <div className="absolute top-4 left-4 z-10">
            <Icon name="sparkle" size={30} />
          </div>
          {/* Animated corner bubble */}
          <div className="absolute -right-9 -bottom-9 w-36 h-36 rounded-full bg-white/20 anim-blob pointer-events-none" />
          <b className="relative z-10 text-xl font-bold font-display leading-tight">
            Вперемешку
          </b>
          <small className="relative z-10 opacity-80 text-xs">Случайные треки из медиатеки</small>
        </button>

        {/* Top Right Tile */}
        <button
          onClick={() => onFilterLib('fav')}
          className="relative p-3.5 px-4 flex flex-col justify-end text-left rounded-[14px_40px_14px_14px] bg-[color-mix(in_srgb,var(--te)_30%,var(--s1))] text-[var(--tx)] shadow-sm card-hoverable btn-spring-active cursor-pointer anim-rise"
          style={{ animationDelay: '0.08s' }}
        >
          <div className="absolute top-3 right-3 text-[var(--tx)] opacity-90">
            <Icon name={favIconStyle === 'heart' ? 'heart' : 'check'} size={22} />
          </div>
          <b className="font-bold text-base">Избранное</b>
          <small className="text-xs text-[var(--mu)]">{favCount} трека</small>
        </button>

        {/* Bottom Right Tile */}
        <button
          onClick={() => onFilterLib('dl')}
          className="relative p-3.5 px-4 flex flex-col justify-end text-left rounded-[14px_14px_40px_14px] bg-[var(--pc)] text-[var(--onpc)] shadow-sm card-hoverable btn-spring-active cursor-pointer anim-rise"
          style={{ animationDelay: '0.12s' }}
        >
          <div className="absolute top-3 right-3 text-[var(--onpc)] opacity-90">
            <Icon name="dl" size={22} />
          </div>
          <b className="font-bold text-base">Загрузки</b>
          <small className="text-xs opacity-75">{downloadedCount} треков</small>
        </button>
      </div>

      {/* Recommendations Rail */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold font-display tracking-tight text-[var(--tx)]">
            Рекомендации
          </h2>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigateTab('settings')}
              aria-label="Настроить ленту"
              className="w-9 h-9 rounded-full flex items-center justify-center text-[var(--p)] bg-[var(--s1)] chip-spring-active cursor-pointer"
            >
              <Icon name="tune" size={18} />
            </button>
            <button
              onClick={() => alert('Лента обновлена')}
              className="h-9 px-4 rounded-full text-xs font-semibold text-[var(--p)] bg-[var(--s1)] chip-spring-active cursor-pointer"
            >
              Обновить
            </button>
          </div>
        </div>

        <div className="flex gap-3.5 overflow-x-auto no-scrollbar -mx-5 px-5 py-2">
          {recommendations.map((track, i) => (
            <div
              key={track.id}
              onClick={() => onPlayTrack(track)}
              onContextMenu={(e) => {
                e.preventDefault();
                onOpenContextMenu(track);
              }}
              className="w-[156px] shrink-0 space-y-2 cursor-pointer card-hoverable anim-rise select-none"
              style={{ animationDelay: `${0.05 * (i + 1)}s` }}
            >
              <CoverArt
                hue={track.hue}
                title={track.title}
                size="full"
                className="w-full aspect-square rounded-[28px]"
              />
              <div className="px-1">
                <b className="block text-sm font-semibold truncate text-[var(--tx)]">
                  {track.title}
                </b>
                <small
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenArtist(track.artist);
                  }}
                  className="block text-xs text-[var(--mu)] truncate hover:underline"
                >
                  {track.artist}
                </small>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Favorites Rail */}
      {favoriteTracks.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-xl font-bold font-display tracking-tight text-[var(--tx)]">
            Избранное
          </h2>

          <div className="flex gap-3.5 overflow-x-auto no-scrollbar -mx-5 px-5 py-2">
            {favoriteTracks.map((track, i) => (
              <div
                key={track.id}
                onClick={() => onPlayTrack(track)}
                onContextMenu={(e) => {
                  e.preventDefault();
                  onOpenContextMenu(track);
                }}
                className="w-[156px] shrink-0 space-y-2 cursor-pointer card-hoverable anim-rise select-none"
                style={{ animationDelay: `${0.05 * (i + 1)}s` }}
              >
                <CoverArt
                  hue={track.hue}
                  title={track.title}
                  size="full"
                  className="w-full aspect-square rounded-[28px]"
                />
                <div className="px-1">
                  <b className="block text-sm font-semibold truncate text-[var(--tx)]">
                    {track.title}
                  </b>
                  <small
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenArtist(track.artist);
                    }}
                    className="block text-xs text-[var(--mu)] truncate hover:underline"
                  >
                    {track.artist}
                  </small>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* All Tracks List */}
      <div className="space-y-3">
        <h2 className="text-xl font-bold font-display tracking-tight text-[var(--tx)]">
          Все треки • {tracks.length}
        </h2>

        <div className="space-y-1">
          {tracks.map((track, i) => {
            const isCurrent = currentTrack?.id === track.id;
            return (
              <div
                key={track.id}
                onClick={() => onPlayTrack(track)}
                onContextMenu={(e) => {
                  e.preventDefault();
                  onOpenContextMenu(track);
                }}
                className={`flex items-center gap-3.5 p-2 px-3 rounded-[20px] cursor-pointer hover:bg-white/5 row-ease-active anim-rise select-none ${
                  isCurrent ? 'bg-[color-mix(in_srgb,var(--pc)_60%,transparent)]' : ''
                }`}
                style={{ animationDelay: `${Math.min(0.4, 0.04 * (i + 1))}s` }}
              >
                <CoverArt
                  hue={track.hue}
                  title={track.title}
                  size="md"
                  className="w-12 h-12 rounded-2xl"
                />

                <div className="min-w-0 flex-1">
                  <b
                    className={`block text-[15px] font-medium truncate ${
                      isCurrent ? 'text-[var(--p)] font-semibold' : 'text-[var(--tx)]'
                    }`}
                  >
                    {track.title}
                  </b>
                  <small
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenArtist(track.artist);
                    }}
                    className="block text-xs text-[var(--mu)] truncate hover:underline"
                  >
                    {track.artist}
                  </small>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDownload(track);
                  }}
                  aria-label="Скачать"
                  className={`w-10 h-10 rounded-full flex items-center justify-center btn-spring-active ${
                    track.isDownloaded ? 'text-[var(--p)]' : 'text-[var(--mu)] hover:text-[var(--tx)]'
                  }`}
                >
                  <Icon name="dl" size={20} />
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleFav(track);
                  }}
                  aria-label="В избранное"
                  className={`w-10 h-10 rounded-full flex items-center justify-center btn-spring-active ${
                    track.isFav
                      ? favIconStyle === 'heart'
                        ? 'text-[var(--te)]'
                        : 'text-[var(--p)] bg-[color-mix(in_srgb,var(--p)_18%,transparent)]'
                      : 'text-[var(--mu)] hover:text-[var(--tx)]'
                  }`}
                >
                  <Icon
                    name={
                      favIconStyle === 'heart'
                        ? 'heart'
                        : track.isFav
                        ? 'check'
                        : 'plus'
                    }
                    size={20}
                  />
                </button>

                <span className="text-xs text-[var(--mu)] font-mono tabular-nums min-w-[34px] text-right">
                  {Math.floor(track.dur / 60)}:
                  {String(Math.floor(track.dur % 60)).padStart(2, '0')}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
