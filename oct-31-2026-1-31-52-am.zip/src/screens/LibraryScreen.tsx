import React, { useState } from 'react';
import { Track } from '../utils/player.ts';
import { Icon } from '../components/Icons.tsx';
import { CoverArt } from '../components/CoverArt.tsx';

interface LibraryScreenProps {
  tracks: Track[];
  currentTrack: Track | null;
  activeFilter: 'all' | 'fav' | 'artists' | 'albums' | 'dl';
  selectedArtist: string | null;
  favIconStyle: 'plus' | 'heart';
  onFilterChange: (filter: 'all' | 'fav' | 'artists' | 'albums' | 'dl') => void;
  onSelectArtist: (artist: string | null) => void;
  onPlayTrack: (track: Track) => void;
  onTogglePlay: () => void;
  onToggleFav: (track: Track) => void;
  onDownload: (track: Track) => void;
  onDeleteTrack: (track: Track) => void;
  onOpenContextMenu: (track: Track) => void;
  onShuffleAll: () => void;
  onPickFiles: () => void;
  onPickFolder: () => void;
}

export const LibraryScreen: React.FC<LibraryScreenProps> = ({
  tracks,
  currentTrack,
  activeFilter,
  selectedArtist,
  favIconStyle,
  onFilterChange,
  onSelectArtist,
  onPlayTrack,
  onToggleFav,
  onDownload,
  onDeleteTrack,
  onOpenContextMenu,
  onShuffleAll,
  onPickFiles,
  onPickFolder,
}) => {
  const [isBioExpanded, setIsBioExpanded] = useState(false);

  // If in Artist Profile view
  if (selectedArtist) {
    const artistTracks = tracks.filter((t) => t.artist === selectedArtist);
    const relatedArtists = [
      { name: 'Ржавый бит', count: '1.4 млн слушателей' },
      { name: 'blair', count: '890 тыс. слушателей' },
      { name: 'Нурминский', count: '2.1 млн слушателей' },
      { name: 'YungMe...', count: '450 тыс. слушателей' },
    ].filter((a) => a.name !== selectedArtist);

    return (
      <div className="space-y-6 pb-36 anim-screen-in">
        {/* Back Button */}
        <div className="pt-2">
          <button
            onClick={() => onSelectArtist(null)}
            aria-label="Назад к медиатеке"
            className="w-12 h-12 rounded-full flex items-center justify-center glass btn-spring-active text-[var(--tx)] cursor-pointer"
          >
            <Icon name="back" size={24} />
          </button>
        </div>

        {/* Artist Hero */}
        <div className="flex items-center gap-4 anim-rise" style={{ animationDelay: '0.04s' }}>
          <div className="w-[104px] h-[104px] rounded-full flex items-center justify-center text-4xl font-bold font-display bg-gradient-to-tr from-[var(--pc)] to-[var(--te)] text-[var(--onp)] shrink-0 shadow-xl">
            {selectedArtist[0]?.toUpperCase() || 'A'}
          </div>

          <div className="min-w-0">
            <h1 className="text-3xl font-bold font-display tracking-tight text-[var(--tx)] truncate">
              {selectedArtist}
            </h1>
            <p className="text-sm text-[var(--mu)] mt-1">
              1.2 млн слушателей в месяц, {artistTracks.length} трека
            </p>
          </div>
        </div>

        {/* Bio */}
        <p
          onClick={() => setIsBioExpanded(!isBioExpanded)}
          className={`text-sm text-[var(--mu)] cursor-pointer hover:text-[var(--tx)] transition-colors leading-relaxed ${
            isBioExpanded ? '' : 'line-clamp-2'
          }`}
        >
          {selectedArtist} — современный артист и автор треков. Экспериментальное звучание,
          глубокий бас и атмосферный вайб. Нажмите, чтобы {isBioExpanded ? 'свернуть' : 'читать подробнее'}.
        </p>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 anim-rise" style={{ animationDelay: '0.08s' }}>
          <button
            onClick={() => artistTracks[0] && onPlayTrack(artistTracks[0])}
            className="h-12 px-6 rounded-full bg-[var(--p)] text-[var(--onp)] font-semibold flex items-center gap-2 shadow-md btn-spring-active cursor-pointer"
          >
            <Icon name="play" size={20} />
            <span>Слушать</span>
          </button>

          <button
            onClick={onShuffleAll}
            className="h-12 px-6 rounded-full bg-[var(--s1)] text-[var(--tx)] font-semibold flex items-center gap-2 hover:bg-white/10 btn-spring-active cursor-pointer"
          >
            <Icon name="shuffle" size={20} />
            <span>Вперемешку</span>
          </button>
        </div>

        {/* Popular Tracks */}
        <div className="space-y-3 pt-2">
          <h2 className="text-xl font-bold font-display text-[var(--tx)]">Популярное</h2>
          <div className="space-y-1">
            {artistTracks.map((track, i) => (
              <div
                key={track.id}
                onClick={() => onPlayTrack(track)}
                onContextMenu={(e) => {
                  e.preventDefault();
                  onOpenContextMenu(track);
                }}
                className="flex items-center gap-3.5 p-2 px-3 rounded-[20px] cursor-pointer hover:bg-white/5 row-ease-active anim-rise select-none"
                style={{ animationDelay: `${0.04 * (i + 1)}s` }}
              >
                <CoverArt hue={track.hue} title={track.title} size="md" className="w-12 h-12 rounded-2xl" />
                <div className="min-w-0 flex-1">
                  <b className="block text-[15px] font-medium truncate text-[var(--tx)]">
                    {track.title}
                  </b>
                  <small className="block text-xs text-[var(--mu)] truncate">
                    {track.artist}
                  </small>
                </div>
                <span className="text-xs text-[var(--mu)] font-mono tabular-nums">
                  {Math.floor(track.dur / 60)}:
                  {String(Math.floor(track.dur % 60)).padStart(2, '0')}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Related Artists */}
        <div className="space-y-3 pt-2">
          <h2 className="text-xl font-bold font-display text-[var(--tx)]">Похожие исполнители</h2>
          <div className="flex gap-4 overflow-x-auto no-scrollbar -mx-5 px-5 py-2">
            {relatedArtists.map((rel, i) => (
              <button
                key={rel.name}
                onClick={() => onSelectArtist(rel.name)}
                className="w-24 shrink-0 flex flex-col items-center gap-2 text-center cursor-pointer card-hoverable anim-rise"
                style={{ animationDelay: `${0.05 * (i + 1)}s` }}
              >
                <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-[var(--pc)] to-[var(--te)] flex items-center justify-center text-2xl font-bold font-display text-[var(--onp)] shadow-md">
                  {rel.name[0]}
                </div>
                <b className="text-xs font-semibold truncate w-full text-[var(--tx)]">
                  {rel.name}
                </b>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Filtered tracks
  let displayedTracks = tracks;
  if (activeFilter === 'fav') {
    displayedTracks = tracks.filter((t) => t.isFav);
  } else if (activeFilter === 'dl') {
    displayedTracks = tracks.filter((t) => t.isDownloaded);
  }

  const artistsList = Array.from(new Set(tracks.map((t) => t.artist)));
  const albumsList = Array.from(new Set(tracks.map((t) => t.album)));

  return (
    <div className="space-y-6 pb-36 anim-screen-in">
      {/* Top Bar */}
      <div className="flex items-center justify-between pt-2">
        <h1 className="text-4xl font-bold font-display tracking-tight text-[var(--tx)]">
          Медиатека
        </h1>

        <div className="flex items-center gap-2">
          <button
            onClick={onPickFolder}
            aria-label="Добавить папку"
            className="w-12 h-12 rounded-full flex items-center justify-center glass btn-spring-active text-[var(--tx)] cursor-pointer"
          >
            <Icon name="folder" size={22} />
          </button>
          <button
            onClick={onPickFiles}
            aria-label="Добавить файлы"
            className="w-12 h-12 rounded-full flex items-center justify-center glass btn-spring-active text-[var(--tx)] cursor-pointer"
          >
            <Icon name="plus" size={22} />
          </button>
        </div>
      </div>

      {/* Filter Chips Horizontal Rail with 350ms ease background, text and border-radius transitions */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-5 px-5 py-1">
        {[
          { id: 'all', label: 'Все' },
          { id: 'fav', label: 'Избранное' },
          { id: 'artists', label: 'Артисты' },
          { id: 'albums', label: 'Альбомы' },
          { id: 'dl', label: 'Загрузки' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => onFilterChange(tab.id as any)}
            className={`h-12 px-5 min-w-[88px] font-semibold text-sm chip-spring-active cursor-pointer ${
              activeFilter === tab.id
                ? 'bg-[var(--p)] text-[var(--onp)] rounded-3xl shadow-md'
                : 'bg-[var(--s1)] text-[var(--mu)] rounded-2xl hover:text-[var(--tx)]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Add Music Banner Card */}
      <button
        onClick={onPickFiles}
        className="w-full p-4 rounded-3xl bg-[var(--s1)] flex items-center gap-4 text-left shadow-sm card-hoverable btn-spring-active cursor-pointer anim-rise"
        style={{ animationDelay: '0.04s' }}
      >
        <div className="w-14 h-14 rounded-full bg-[var(--p)] text-[var(--onp)] flex items-center justify-center shrink-0 shadow-md">
          <Icon name="plus" size={28} />
        </div>
        <div className="min-w-0 flex-1">
          <b className="block text-base font-bold text-[var(--tx)]">Добавить музыку</b>
          <small className="block text-xs text-[var(--mu)] truncate mt-0.5">
            {tracks.length} треков, хранятся на устройстве и доступны офлайн
          </small>
        </div>
      </button>

      {/* Conditional rendering for Artists tab */}
      {activeFilter === 'artists' && (
        <div className="grid grid-cols-2 gap-4">
          {artistsList.map((artist, i) => {
            const count = tracks.filter((t) => t.artist === artist).length;
            return (
              <button
                key={artist}
                onClick={() => onSelectArtist(artist)}
                className="p-4 rounded-3xl bg-[var(--s1)] flex flex-col items-center gap-2 text-center card-hoverable btn-spring-active cursor-pointer anim-rise"
                style={{ animationDelay: `${0.04 * (i + 1)}s` }}
              >
                <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-[var(--pc)] to-[var(--te)] flex items-center justify-center text-3xl font-bold font-display text-[var(--onp)] shadow-md">
                  {artist[0]?.toUpperCase() || 'A'}
                </div>
                <b className="font-bold text-sm truncate w-full text-[var(--tx)]">{artist}</b>
                <small className="text-xs text-[var(--mu)]">{count} трека</small>
              </button>
            );
          })}
        </div>
      )}

      {/* Conditional rendering for Albums tab */}
      {activeFilter === 'albums' && (
        <div className="grid grid-cols-2 gap-4">
          {albumsList.map((album, i) => {
            const albumTracks = tracks.filter((t) => t.album === album);
            return (
              <div
                key={album}
                onClick={() => {
                  if (albumTracks[0]) onPlayTrack(albumTracks[0]);
                }}
                className="p-3.5 rounded-3xl bg-[var(--s1)] flex flex-col gap-2 card-hoverable btn-spring-active cursor-pointer anim-rise"
                style={{ animationDelay: `${0.04 * (i + 1)}s` }}
              >
                <CoverArt
                  hue={albumTracks[0]?.hue}
                  title={album}
                  size="full"
                  className="rounded-2xl"
                />
                <b className="font-bold text-sm truncate text-[var(--tx)]">{album}</b>
                <small className="text-xs text-[var(--mu)]">{albumTracks.length} трека</small>
              </div>
            );
          })}
        </div>
      )}

      {/* Main track list for All, Fav, Dl */}
      {activeFilter !== 'artists' && activeFilter !== 'albums' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold font-display text-[var(--tx)]">
              {activeFilter === 'fav'
                ? 'Избранное'
                : activeFilter === 'dl'
                ? 'Загрузки'
                : 'Все треки'}{' '}
              • {displayedTracks.length}
            </h2>

            {displayedTracks.length > 0 && (
              <button
                onClick={onShuffleAll}
                aria-label="Перемешать всё"
                className="w-12 h-12 rounded-full flex items-center justify-center text-[var(--p)] bg-[color-mix(in_srgb,var(--p)_16%,transparent)] hover:bg-[color-mix(in_srgb,var(--p)_26%,transparent)] btn-spring-active cursor-pointer"
              >
                <Icon name="shuffle" size={22} />
              </button>
            )}
          </div>

          {displayedTracks.length === 0 ? (
            <div className="py-12 text-center text-[var(--mu)] space-y-2">
              <p className="text-lg font-semibold text-[var(--tx)]">Пока пусто</p>
              <p className="text-sm">
                {activeFilter === 'fav'
                  ? 'Добавьте треки в избранное с помощью кнопки +'
                  : 'Скачанные файлы будут отображаться здесь'}
              </p>
            </div>
          ) : (
            <div className="space-y-1">
              {displayedTracks.map((track, i) => {
                const isCurrent = currentTrack?.id === track.id;
                return (
                  <div
                    key={track.id}
                    onClick={() => onPlayTrack(track)}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      onOpenContextMenu(track);
                    }}
                    className={`flex items-center gap-3.5 p-2 px-3 rounded-[20px] cursor-pointer hover:bg-white/5 row-ease-active anim-rise select-none ${
                      isCurrent ? 'bg-[color-mix(in_srgb,var(--pc)_60%,transparent)]' : ''
                    }`}
                    style={{ animationDelay: `${Math.min(0.4, 0.04 * (i + 1))}s` }}
                  >
                    <CoverArt
                      hue={track.hue}
                      title={track.title}
                      size="md"
                      className="w-12 h-12 rounded-2xl"
                    />

                    <div className="min-w-0 flex-1">
                      <b
                        className={`block text-[15px] font-medium truncate ${
                          isCurrent ? 'text-[var(--p)] font-semibold' : 'text-[var(--tx)]'
                        }`}
                      >
                        {track.title}
                      </b>
                      <small
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectArtist(track.artist);
                        }}
                        className="block text-xs text-[var(--mu)] truncate hover:underline"
                      >
                        {track.artist}
                      </small>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDownload(track);
                      }}
                      aria-label="Скачать"
                      className={`w-10 h-10 rounded-full flex items-center justify-center btn-spring-active ${
                        track.isDownloaded ? 'text-[var(--p)]' : 'text-[var(--mu)] hover:text-[var(--tx)]'
                      }`}
                    >
                      <Icon name="dl" size={20} />
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFav(track);
                      }}
                      aria-label="В избранное"
                      className={`w-10 h-10 rounded-full flex items-center justify-center btn-spring-active ${
                        track.isFav
                          ? favIconStyle === 'heart'
                            ? 'text-[var(--te)]'
                            : 'text-[var(--p)] bg-[color-mix(in_srgb,var(--p)_18%,transparent)]'
                          : 'text-[var(--mu)] hover:text-[var(--tx)]'
                      }`}
                    >
                      <Icon
                        name={
                          favIconStyle === 'heart'
                            ? 'heart'
                            : track.isFav
                            ? 'check'
                            : 'plus'
                        }
                        size={20}
                      />
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteTrack(track);
                      }}
                      aria-label="Удалить из библиотеки"
                      className="w-10 h-10 rounded-full flex items-center justify-center text-[var(--mu)] hover:text-rose-400 btn-spring-active"
                    >
                      <Icon name="x" size={18} />
                    </button>

                    <span className="text-xs text-[var(--mu)] font-mono tabular-nums min-w-[34px] text-right">
                      {Math.floor(track.dur / 60)}:
                      {String(Math.floor(track.dur % 60)).padStart(2, '0')}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
