import React, { useState } from 'react';
import { Track } from '../utils/player.ts';
import { Icon } from '../components/Icons.tsx';
import { CoverArt } from '../components/CoverArt.tsx';
import { RECENT_SEARCHES } from '../data/mockTracks.ts';

interface SearchScreenProps {
  tracks: Track[];
  currentTrack: Track | null;
  favIconStyle: 'plus' | 'heart';
  onPlayTrack: (track: Track) => void;
  onToggleFav: (track: Track) => void;
  onDownload: (track: Track) => void;
  onOpenContextMenu: (track: Track) => void;
  onOpenArtist: (artist: string) => void;
}

export const SearchScreen: React.FC<SearchScreenProps> = ({
  tracks,
  currentTrack,
  favIconStyle,
  onPlayTrack,
  onToggleFav,
  onDownload,
  onOpenContextMenu,
  onOpenArtist,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [recentList, setRecentList] = useState<string[]>(RECENT_SEARCHES);

  const filtered = searchQuery.trim()
    ? tracks.filter(
        (t) =>
          t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          t.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
          t.album.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const handleClearRecent = () => {
    setRecentList([]);
  };

  const handleSelectRecent = (q: string) => {
    setSearchQuery(q);
  };

  return (
    <div className="space-y-6 pb-36 anim-screen-in">
      <h1 className="text-4xl font-bold font-display tracking-tight text-[var(--tx)] pt-2">
        Поиск
      </h1>

      {/* Pill Search Field with purple outline */}
      <div className="flex items-center gap-3 h-16 px-5 rounded-full border-2 border-[var(--p)] bg-[color-mix(in_srgb,var(--s1)_75%,transparent)] shadow-lg transition-all">
        <span className="text-[var(--p)] shrink-0">
          <Icon name="search" size={24} />
        </span>
        <input
          type="search"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Песни, исполнители, ссылка YouTube"
          autoComplete="off"
          className="flex-1 min-w-0 bg-transparent text-[var(--tx)] text-lg placeholder:text-[var(--mu)] outline-none"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            aria-label="Очистить поиск"
            className="w-8 h-8 rounded-full flex items-center justify-center text-[var(--mu)] hover:text-[var(--tx)] btn-spring-active"
          >
            <Icon name="x" size={20} />
          </button>
        )}
      </div>

      {/* Recent Queries */}
      {!searchQuery && recentList.length > 0 && (
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-[var(--mu)]">Недавние запросы</h2>
            <button
              onClick={handleClearRecent}
              className="h-8 px-3 rounded-full text-xs font-semibold text-[var(--p)] chip-spring-active cursor-pointer"
            >
              Очистить всё
            </button>
          </div>

          <div className="flex flex-wrap gap-2">
            {recentList.map((query, i) => (
              <button
                key={query}
                onClick={() => handleSelectRecent(query)}
                className="h-10 px-4 rounded-2xl bg-[var(--s1)] text-[var(--tx)] text-sm font-medium chip-spring-active cursor-pointer anim-rise"
                style={{ animationDelay: `${0.04 * (i + 1)}s` }}
              >
                {query}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Search Results */}
      {searchQuery && (
        <div className="space-y-3 pt-2">
          <h2 className="text-lg font-bold font-display text-[var(--tx)]">
            Результаты поиска • {filtered.length}
          </h2>

          {filtered.length === 0 ? (
            <div className="py-12 text-center text-[var(--mu)] space-y-2">
              <p className="text-lg font-semibold text-[var(--tx)]">Ничего не найдено</p>
              <p className="text-sm">Проверьте написание или поищите по исполнителю</p>
            </div>
          ) : (
            <div className="space-y-1">
              {filtered.map((track, i) => {
                const isCurrent = currentTrack?.id === track.id;
                return (
                  <div
                    key={track.id}
                    onClick={() => onPlayTrack(track)}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      onOpenContextMenu(track);
                    }}
                    className={`flex items-center gap-3.5 p-2 px-3 rounded-[20px] cursor-pointer hover:bg-white/5 row-ease-active anim-rise select-none ${
                      isCurrent ? 'bg-[color-mix(in_srgb,var(--pc)_60%,transparent)]' : ''
                    }`}
                    style={{ animationDelay: `${Math.min(0.4, 0.04 * (i + 1))}s` }}
                  >
                    <CoverArt
                      hue={track.hue}
                      title={track.title}
                      size="md"
                      className="w-12 h-12 rounded-2xl"
                    />

                    <div className="min-w-0 flex-1">
                      <b
                        className={`block text-[15px] font-medium truncate ${
                          isCurrent ? 'text-[var(--p)] font-semibold' : 'text-[var(--tx)]'
                        }`}
                      >
                        {track.title}
                      </b>
                      <small
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenArtist(track.artist);
                        }}
                        className="block text-xs text-[var(--mu)] truncate hover:underline"
                      >
                        {track.artist}
                      </small>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDownload(track);
                      }}
                      aria-label="Скачать"
                      className={`w-10 h-10 rounded-full flex items-center justify-center btn-spring-active ${
                        track.isDownloaded ? 'text-[var(--p)]' : 'text-[var(--mu)] hover:text-[var(--tx)]'
                      }`}
                    >
                      <Icon name="dl" size={20} />
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFav(track);
                      }}
                      aria-label="В избранное"
                      className={`w-10 h-10 rounded-full flex items-center justify-center btn-spring-active ${
                        track.isFav
                          ? favIconStyle === 'heart'
                            ? 'text-[var(--te)]'
                            : 'text-[var(--p)] bg-[color-mix(in_srgb,var(--p)_18%,transparent)]'
                          : 'text-[var(--mu)] hover:text-[var(--tx)]'
                      }`}
                    >
                      <Icon
                        name={
                          favIconStyle === 'heart'
                            ? 'heart'
                            : track.isFav
                            ? 'check'
                            : 'plus'
                        }
                        size={20}
                      />
                    </button>

                    <span className="text-xs text-[var(--mu)] font-mono tabular-nums">
                      {Math.floor(track.dur / 60)}:
                      {String(Math.floor(track.dur % 60)).padStart(2, '0')}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Footer Signature */}
      <footer className="pt-16 text-center text-[var(--mu)] text-xs opacity-70">
        #вайбкод | riasodrochh made
      </footer>
    </div>
  );
};
