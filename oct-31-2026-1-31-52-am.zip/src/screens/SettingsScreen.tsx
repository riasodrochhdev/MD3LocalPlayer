import React, { useState } from 'react';
import { ThemeName, THEMES } from '../utils/player.ts';
import { Icon } from '../components/Icons.tsx';
import { GENRES } from '../data/mockTracks.ts';

interface SettingsScreenProps {
  currentTheme: ThemeName;
  onSelectTheme: (theme: ThemeName) => void;
  glassMode: 'off' | 'blur' | 'liquid';
  onChangeGlassMode: (mode: 'off' | 'blur' | 'liquid') => void;
  snowEnabled: boolean;
  onToggleSnow: () => void;
  favIconStyle: 'plus' | 'heart';
  onChangeFavIconStyle: (style: 'plus' | 'heart') => void;
  hapticEnabled: boolean;
  onToggleHaptic: () => void;
  motionMode: 'full' | 'system' | 'reduced';
  onToggleMotion: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  currentTheme,
  onSelectTheme,
  glassMode,
  onChangeGlassMode,
  snowEnabled,
  onToggleSnow,
  favIconStyle,
  onChangeFavIconStyle,
  hapticEnabled,
  onToggleHaptic,
  motionMode,
  onToggleMotion,
}) => {
  const [activeTab, setActiveTab] = useState<'look' | 'bg' | 'feed' | 'services'>('look');

  // Background tab states
  const [bgMode, setBgMode] = useState<'off' | 'fluid' | 'waves'>('fluid');
  const [bgCoverAdaptive, setBgCoverAdaptive] = useState(true);
  const [bgPlayOnly, setBgPlayOnly] = useState(false);
  const [bgSpeed, setBgSpeed] = useState<number>(3); // 1 = slow, 2 = mid, 3 = fast
  const [bgIntensity, setBgIntensity] = useState<number>(1); // 1 = soft, 2 = mid, 3 = bright

  // Feed tab states
  const [trackLanguage, setTrackLanguage] = useState<'fav' | 'any' | 'pref' | 'ru'>('fav');
  const [customArtists, setCustomArtists] = useState<string[]>([
    'ermachka0',
    'wifiskeleton',
    'blair',
    'onda andar',
  ]);
  const [artistInput, setArtistInput] = useState('');
  const [selectedGenres, setSelectedGenres] = useState<string[]>(['rap', 'indie', 'phonk']);
  const [trackCap, setTrackCap] = useState<number>(3);
  const [feedSize, setFeedSize] = useState<number>(30);
  const [listenTaste, setListenTaste] = useState(true);
  const [audiusEnabled, setAudiusEnabled] = useState(true);
  const [ytEnabled, setYtEnabled] = useState(true);
  const [flowEnabled, setFlowEnabled] = useState(true);
  const [autoScroll, setAutoScroll] = useState(false);

  // Services tab states
  const [dlLocation, setDlLocation] = useState<'both' | 'lib' | 'file'>('both');
  const [gatewayUrl, setGatewayUrl] = useState('worker.vanekdzdva.workers.dev');

  const handleAddArtist = () => {
    if (!artistInput.trim()) return;
    if (!customArtists.includes(artistInput.trim())) {
      setCustomArtists([...customArtists, artistInput.trim()]);
    }
    setArtistInput('');
  };

  const handleRemoveArtist = (name: string) => {
    setCustomArtists(customArtists.filter((a) => a !== name));
  };

  const toggleGenre = (genreId: string) => {
    setSelectedGenres((prev) =>
      prev.includes(genreId) ? prev.filter((g) => g !== genreId) : [...prev, genreId]
    );
  };

  return (
    <div className="space-y-5 pb-36 anim-screen-in">
      {/* Top Header */}
      <h1 className="text-4xl font-bold font-display tracking-tight text-[var(--tx)] pt-2">
        Настройки
      </h1>

      {/* 4 Segmented Tabs */}
      <div className="flex gap-1.5 p-1 rounded-2xl bg-[var(--s1)]">
        {[
          { id: 'look', label: 'Вид' },
          { id: 'bg', label: 'Фон' },
          { id: 'feed', label: 'Лента' },
          { id: 'services', label: 'Сервисы' },
        ].map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 h-11 rounded-xl text-sm font-semibold transition-all duration-350 ease-[cubic-bezier(0.2,0.8,0.2,1)] btn-spring-active cursor-pointer ${
                isActive
                  ? 'bg-[var(--p)] text-[var(--onp)] shadow-sm'
                  : 'text-[var(--mu)] hover:text-[var(--tx)]'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* TAB 1: ВИД */}
      {activeTab === 'look' && (
        <div className="space-y-4">
          {/* Card: Тема */}
          <section className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-4 shadow-sm anim-rise">
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Тема</h3>

            <div className="grid grid-cols-4 gap-3 text-center">
              {THEMES.map((theme) => {
                const isSelected = currentTheme === theme.id;
                return (
                  <button
                    key={theme.id}
                    onClick={() => onSelectTheme(theme.id)}
                    className="flex flex-col items-center gap-2 py-1.5 cursor-pointer btn-spring-active"
                  >
                    <div
                      className={`w-13 h-13 rounded-full border-3 shadow-md transition-all duration-300 ${
                        isSelected
                          ? 'border-[var(--p)] scale-110 shadow-lg'
                          : 'border-transparent hover:scale-105'
                      }`}
                      style={{
                        background: `linear-gradient(135deg, ${theme.bg} 50%, ${theme.color} 50%)`,
                      }}
                    />
                    <span
                      className={`text-xs font-medium truncate w-full ${
                        isSelected ? 'text-[var(--tx)] font-bold' : 'text-[var(--mu)]'
                      }`}
                    >
                      {theme.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Card: Стекло */}
          <section
            className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-3 shadow-sm anim-rise"
            style={{ animationDelay: '0.04s' }}
          >
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Стекло</h3>

            <div className="flex gap-1.5 p-1 rounded-2xl bg-[var(--s1)]">
              {[
                { id: 'off', label: 'Без размытия' },
                { id: 'blur', label: 'Размытие' },
                { id: 'liquid', label: 'Liquid Glass' },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => onChangeGlassMode(m.id as any)}
                  className={`flex-1 h-11 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-300 btn-spring-active cursor-pointer ${
                    glassMode === m.id
                      ? 'bg-[var(--p)] text-[var(--onp)] shadow-sm'
                      : 'text-[var(--mu)] hover:text-[var(--tx)]'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </section>

          {/* Card: Снежинки */}
          <section
            className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-3 shadow-sm anim-rise"
            style={{ animationDelay: '0.08s' }}
          >
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Снежинки</h3>

            <div className="flex items-center justify-between">
              <div>
                <b className="block text-sm font-semibold text-[var(--tx)]">Падающий снег</b>
                <small className="block text-xs text-[var(--mu)]">
                  Лёгкая анимация поверх всего приложения
                </small>
              </div>

              <button
                onClick={onToggleSnow}
                role="switch"
                aria-checked={snowEnabled}
                className={`w-13 h-8 rounded-full p-1 transition-colors duration-300 relative cursor-pointer ${
                  snowEnabled ? 'bg-[var(--p)]' : 'bg-white/15'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full transition-transform duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] shadow-sm ${
                    snowEnabled
                      ? 'translate-x-5 bg-[var(--onp)]'
                      : 'translate-x-0 bg-[var(--mu)]'
                  }`}
                />
              </button>
            </div>
          </section>

          {/* Card: Значок «в избранное» */}
          <section
            className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-3 shadow-sm anim-rise"
            style={{ animationDelay: '0.12s' }}
          >
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">
              Значок «в избранное»
            </h3>

            <div className="flex gap-2">
              <button
                onClick={() => onChangeFavIconStyle('plus')}
                className={`flex-1 h-12 rounded-2xl text-sm font-semibold transition-all duration-300 btn-spring-active cursor-pointer ${
                  favIconStyle === 'plus'
                    ? 'bg-[var(--p)] text-[var(--onp)] shadow-sm'
                    : 'bg-[var(--s1)] text-[var(--mu)]'
                }`}
              >
                Плюс
              </button>

              <button
                onClick={() => onChangeFavIconStyle('heart')}
                className={`flex-1 h-12 rounded-2xl text-sm font-semibold transition-all duration-300 btn-spring-active cursor-pointer ${
                  favIconStyle === 'heart'
                    ? 'bg-[var(--p)] text-[var(--onp)] shadow-sm'
                    : 'bg-[var(--s1)] text-[var(--mu)]'
                }`}
              >
                Сердце
              </button>
            </div>
          </section>

          {/* Card: Отклик и анимации */}
          <section
            className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-4 shadow-sm anim-rise"
            style={{ animationDelay: '0.16s' }}
          >
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Отклик и анимации</h3>

            <div className="flex items-center justify-between">
              <div>
                <b className="block text-sm font-semibold text-[var(--tx)]">Вибрация</b>
                <small className="block text-xs text-[var(--mu)]">
                  Лёгкий отклик на нажатия, свайпы и долгое нажатие
                </small>
              </div>

              <button
                onClick={onToggleHaptic}
                role="switch"
                aria-checked={hapticEnabled}
                className={`w-13 h-8 rounded-full p-1 transition-colors duration-300 relative cursor-pointer ${
                  hapticEnabled ? 'bg-[var(--p)]' : 'bg-white/15'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full transition-transform duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)] shadow-sm ${
                    hapticEnabled
                      ? 'translate-x-5 bg-[var(--onp)]'
                      : 'translate-x-0 bg-[var(--mu)]'
                  }`}
                />
              </button>
            </div>

            <button
              onClick={onToggleMotion}
              className="w-full h-12 rounded-2xl bg-[var(--s1)] text-[var(--tx)] text-sm font-semibold hover:bg-white/10 btn-spring-active cursor-pointer"
            >
              {motionMode === 'full'
                ? 'Анимации: всегда включены'
                : motionMode === 'reduced'
                ? 'Анимации: выключены'
                : 'Анимации: как в настройках системы'}
            </button>
          </section>

          <footer className="pt-4 text-center text-[var(--mu)] text-xs opacity-70">
            #вайбкод | riasodrochh made
          </footer>
        </div>
      )}

      {/* TAB 2: ФОН */}
      {activeTab === 'bg' && (
        <div className="space-y-4">
          <section className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-4 shadow-sm anim-rise">
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Анимированный фон</h3>
            <p className="text-xs text-[var(--mu)] leading-relaxed">
              Фон виден за этими карточками, поэтому изменения заметны сразу.
            </p>

            <div className="flex gap-2">
              {[
                { id: 'off', label: 'Статичный' },
                { id: 'fluid', label: 'Пятна' },
                { id: 'waves', label: 'Волны' },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => setBgMode(m.id as any)}
                  className={`flex-1 h-12 rounded-2xl text-sm font-semibold transition-all duration-300 btn-spring-active cursor-pointer ${
                    bgMode === m.id
                      ? 'bg-[var(--p)] text-[var(--onp)] shadow-sm'
                      : 'bg-[var(--s1)] text-[var(--mu)]'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-between pt-2">
              <div>
                <b className="block text-sm font-semibold text-[var(--tx)]">Цвета по обложке</b>
                <small className="block text-xs text-[var(--mu)]">
                  Фон подстраивается под играющий трек
                </small>
              </div>
              <button
                onClick={() => setBgCoverAdaptive(!bgCoverAdaptive)}
                role="switch"
                aria-checked={bgCoverAdaptive}
                className={`w-13 h-8 rounded-full p-1 transition-colors duration-300 relative cursor-pointer ${
                  bgCoverAdaptive ? 'bg-[var(--p)]' : 'bg-white/15'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full transition-transform duration-300 shadow-sm ${
                    bgCoverAdaptive
                      ? 'translate-x-5 bg-[var(--onp)]'
                      : 'translate-x-0 bg-[var(--mu)]'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between pt-1">
              <div>
                <b className="block text-sm font-semibold text-[var(--tx)]">
                  Двигать только во время музыки
                </b>
                <small className="block text-xs text-[var(--mu)]">
                  На паузе фон замирает почти полностью
                </small>
              </div>
              <button
                onClick={() => setBgPlayOnly(!bgPlayOnly)}
                role="switch"
                aria-checked={bgPlayOnly}
                className={`w-13 h-8 rounded-full p-1 transition-colors duration-300 relative cursor-pointer ${
                  bgPlayOnly ? 'bg-[var(--p)]' : 'bg-white/15'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full transition-transform duration-300 shadow-sm ${
                    bgPlayOnly
                      ? 'translate-x-5 bg-[var(--onp)]'
                      : 'translate-x-0 bg-[var(--mu)]'
                  }`}
                />
              </button>
            </div>

            {/* Скорость */}
            <div className="space-y-2 pt-2">
              <span className="text-xs font-semibold text-[var(--mu)]">Скорость</span>
              <div className="flex gap-2">
                {[
                  { id: 1, label: 'Медленно' },
                  { id: 2, label: 'Средне' },
                  { id: 3, label: 'Быстро' },
                ].map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setBgSpeed(s.id)}
                    className={`flex-1 h-11 rounded-2xl text-xs sm:text-sm font-semibold transition-all duration-300 btn-spring-active cursor-pointer ${
                      bgSpeed === s.id
                        ? 'bg-[var(--p)] text-[var(--onp)] shadow-sm'
                        : 'bg-[var(--s1)] text-[var(--mu)]'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Насыщенность */}
            <div className="space-y-2 pt-2">
              <span className="text-xs font-semibold text-[var(--mu)]">Насыщенность</span>
              <div className="flex gap-2">
                {[
                  { id: 1, label: 'Мягко' },
                  { id: 2, label: 'Средне' },
                  { id: 3, label: 'Ярко' },
                ].map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setBgIntensity(s.id)}
                    className={`flex-1 h-11 rounded-2xl text-xs sm:text-sm font-semibold transition-all duration-300 btn-spring-active cursor-pointer ${
                      bgIntensity === s.id
                        ? 'bg-[var(--p)] text-[var(--onp)] shadow-sm'
                        : 'bg-[var(--s1)] text-[var(--mu)]'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          </section>
        </div>
      )}

      {/* TAB 3: ЛЕНТА */}
      {activeTab === 'feed' && (
        <div className="space-y-4">
          {/* Card: Как строится лента */}
          <section className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-2 shadow-sm anim-rise">
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Как строится лента</h3>
            <p className="text-xs text-[var(--mu)] leading-relaxed">
              Главный источник — ваше избранное: берутся похожие на него треки и связанные исполнители
              (с Яндексом это «похожие треки», без него — Audius). Ниже можно добавить свои исполнители и
              жанры.
            </p>
          </section>

          {/* Card: Язык треков */}
          <section
            className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-3 shadow-sm anim-rise"
            style={{ animationDelay: '0.04s' }}
          >
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Язык треков</h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'fav', label: 'По вкусу' },
                { id: 'any', label: 'Любой' },
                { id: 'pref', label: 'Больше русских' },
                { id: 'ru', label: 'Только русские' },
              ].map((l) => (
                <button
                  key={l.id}
                  onClick={() => setTrackLanguage(l.id as any)}
                  className={`h-12 px-2 rounded-2xl text-xs font-semibold transition-all duration-300 btn-spring-active cursor-pointer ${
                    trackLanguage === l.id
                      ? 'bg-[var(--p)] text-[var(--onp)] shadow-sm'
                      : 'bg-[var(--s1)] text-[var(--mu)]'
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>

            <p className="text-xs text-[var(--mu)] leading-relaxed">
              «По вкусу» сам выбирает язык по вашему избранному. Исполнители из вашего списка
              показываются всегда.
            </p>
          </section>

          {/* Card: Мои исполнители */}
          <section
            className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-3 shadow-sm anim-rise"
            style={{ animationDelay: '0.08s' }}
          >
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Мои исполнители</h3>

            <div className="flex flex-wrap gap-2">
              {customArtists.map((artist) => (
                <button
                  key={artist}
                  onClick={() => handleRemoveArtist(artist)}
                  className="h-10 px-4 rounded-2xl bg-[var(--p)] text-[var(--onp)] text-xs font-semibold flex items-center gap-1.5 btn-spring-active cursor-pointer"
                >
                  <span>{artist}</span>
                  <Icon name="x" size={16} />
                </button>
              ))}
            </div>

            <div className="flex gap-2 pt-1">
              <input
                type="text"
                value={artistInput}
                onChange={(e) => setArtistInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddArtist()}
                placeholder="Например: Кино"
                className="flex-1 min-w-0 h-11 px-4 rounded-2xl bg-[color-mix(in_srgb,var(--s1)_80%,transparent)] border border-white/10 text-sm text-[var(--tx)] placeholder:text-[var(--mu)] outline-none focus:border-[var(--p)]"
              />
              <button
                onClick={handleAddArtist}
                aria-label="Добавить исполнителя"
                className="w-11 h-11 rounded-2xl bg-[var(--p)] text-[var(--onp)] flex items-center justify-center shrink-0 btn-spring-active cursor-pointer"
              >
                <Icon name="plus" size={20} />
              </button>
            </div>
          </section>

          {/* Card: Жанры */}
          <section
            className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-3 shadow-sm anim-rise"
            style={{ animationDelay: '0.12s' }}
          >
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Жанры</h3>

            <div className="flex flex-wrap gap-2">
              {GENRES.map(([id, label]) => {
                const isSelected = selectedGenres.includes(id);
                return (
                  <button
                    key={id}
                    onClick={() => toggleGenre(id)}
                    className={`h-9 px-4 rounded-full text-xs font-semibold chip-spring-active cursor-pointer ${
                      isSelected
                        ? 'bg-[var(--p)] text-[var(--onp)] shadow-sm'
                        : 'bg-[var(--s1)] text-[var(--mu)]'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </section>

          {/* Card: Объём */}
          <section
            className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-4 shadow-sm anim-rise"
            style={{ animationDelay: '0.16s' }}
          >
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Объём</h3>

            <div className="space-y-2">
              <span className="text-xs font-semibold text-[var(--mu)]">
                Треков одного исполнителя
              </span>
              <div className="grid grid-cols-4 gap-2">
                {[1, 2, 3, 5].map((val) => (
                  <button
                    key={val}
                    onClick={() => setTrackCap(val)}
                    className={`h-11 rounded-2xl text-sm font-semibold transition-all duration-300 btn-spring-active cursor-pointer ${
                      trackCap === val
                        ? 'bg-[var(--p)] text-[var(--onp)] shadow-sm'
                        : 'bg-[var(--s1)] text-[var(--mu)]'
                    }`}
                  >
                    {val}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <span className="text-xs font-semibold text-[var(--mu)]">Размер ленты</span>
              <div className="grid grid-cols-3 gap-2">
                {[10, 20, 30].map((val) => (
                  <button
                    key={val}
                    onClick={() => setFeedSize(val)}
                    className={`h-11 rounded-2xl text-sm font-semibold transition-all duration-300 btn-spring-active cursor-pointer ${
                      feedSize === val
                        ? 'bg-[var(--p)] text-[var(--onp)] shadow-sm'
                        : 'bg-[var(--s1)] text-[var(--mu)]'
                    }`}
                  >
                    {val}
                  </button>
                ))}
              </div>
            </div>
          </section>

          {/* Card: Источники и поведение */}
          <section
            className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-3.5 shadow-sm anim-rise"
            style={{ animationDelay: '0.2s' }}
          >
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">
              Источники и поведение
            </h3>

            <div className="flex items-center justify-between">
              <div>
                <b className="block text-sm font-semibold text-[var(--tx)]">
                  Учитывать прослушивания
                </b>
                <small className="block text-xs text-[var(--mu)]">Если избранного мало</small>
              </div>
              <button
                onClick={() => setListenTaste(!listenTaste)}
                role="switch"
                aria-checked={listenTaste}
                className={`w-13 h-8 rounded-full p-1 transition-colors duration-300 relative cursor-pointer ${
                  listenTaste ? 'bg-[var(--p)]' : 'bg-white/15'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full transition-transform duration-300 shadow-sm ${
                    listenTaste ? 'translate-x-5 bg-[var(--onp)]' : 'translate-x-0 bg-[var(--mu)]'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <b className="text-sm font-semibold text-[var(--tx)]">Audius</b>
              <button
                onClick={() => setAudiusEnabled(!audiusEnabled)}
                role="switch"
                aria-checked={audiusEnabled}
                className={`w-13 h-8 rounded-full p-1 transition-colors duration-300 relative cursor-pointer ${
                  audiusEnabled ? 'bg-[var(--p)]' : 'bg-white/15'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full transition-transform duration-300 shadow-sm ${
                    audiusEnabled ? 'translate-x-5 bg-[var(--onp)]' : 'translate-x-0 bg-[var(--mu)]'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <b className="block text-sm font-semibold text-[var(--tx)]">YouTube Music</b>
                <small className="block text-xs text-[var(--mu)]">
                  Нужен рабочий Piped или свой воркер
                </small>
              </div>
              <button
                onClick={() => setYtEnabled(!ytEnabled)}
                role="switch"
                aria-checked={ytEnabled}
                className={`w-13 h-8 rounded-full p-1 transition-colors duration-300 relative cursor-pointer ${
                  ytEnabled ? 'bg-[var(--p)]' : 'bg-white/15'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full transition-transform duration-300 shadow-sm ${
                    ytEnabled ? 'translate-x-5 bg-[var(--onp)]' : 'translate-x-0 bg-[var(--mu)]'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <b className="block text-sm font-semibold text-[var(--tx)]">
                  Играть дальше по ленте
                </b>
                <small className="block text-xs text-[var(--mu)]">
                  После трека включается следующий из ленты
                </small>
              </div>
              <button
                onClick={() => setFlowEnabled(!flowEnabled)}
                role="switch"
                aria-checked={flowEnabled}
                className={`w-13 h-8 rounded-full p-1 transition-colors duration-300 relative cursor-pointer ${
                  flowEnabled ? 'bg-[var(--p)]' : 'bg-white/15'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full transition-transform duration-300 shadow-sm ${
                    flowEnabled ? 'translate-x-5 bg-[var(--onp)]' : 'translate-x-0 bg-[var(--mu)]'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <b className="block text-sm font-semibold text-[var(--tx)]">
                  Листать ленту самой
                </b>
                <small className="block text-xs text-[var(--mu)]">Каждые несколько секунд</small>
              </div>
              <button
                onClick={() => setAutoScroll(!autoScroll)}
                role="switch"
                aria-checked={autoScroll}
                className={`w-13 h-8 rounded-full p-1 transition-colors duration-300 relative cursor-pointer ${
                  autoScroll ? 'bg-[var(--p)]' : 'bg-white/15'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full transition-transform duration-300 shadow-sm ${
                    autoScroll ? 'translate-x-5 bg-[var(--onp)]' : 'translate-x-0 bg-[var(--mu)]'
                  }`}
                />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => alert('Лента обновлена')}
                className="h-11 rounded-2xl bg-[var(--s1)] text-[var(--tx)] text-xs font-semibold hover:bg-white/10 btn-spring-active cursor-pointer"
              >
                Обновить ленту
              </button>

              <button
                onClick={() => alert('Вкус сброшен')}
                className="h-11 rounded-2xl bg-[var(--s1)] text-[var(--tx)] text-xs font-semibold hover:bg-white/10 btn-spring-active cursor-pointer"
              >
                Сбросить мой вкус
              </button>
            </div>
          </section>
        </div>
      )}

      {/* TAB 4: СЕРВИСЫ */}
      {activeTab === 'services' && (
        <div className="space-y-4">
          {/* Card: Яндекс Музыка */}
          <section className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-3.5 shadow-sm anim-rise">
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Яндекс Музыка</h3>
            <p className="text-xs text-[var(--mu)] leading-relaxed">
              Поиск, «Моя волна», похожие треки, профили исполнителей и скачивание. Неофициальный API:
              может перестать работать, если Яндекс его изменит.
            </p>

            <p className="text-xs text-[var(--mu)] font-mono">
              Шлюз: <b className="text-[var(--tx)]">{gatewayUrl}</b>
            </p>

            <button
              onClick={() => alert('Вход через Яндекс')}
              className="w-full h-12 rounded-2xl bg-[var(--p)] text-[var(--onp)] font-semibold text-sm btn-spring-active cursor-pointer shadow-md"
            >
              Войти через Яндекс
            </button>

            <div className="flex gap-2">
              <button
                onClick={() => alert('Вставьте токен Яндекс Музыки')}
                className="flex-1 h-11 rounded-2xl bg-[var(--s1)] text-[var(--tx)] text-xs font-semibold hover:bg-white/10 btn-spring-active cursor-pointer"
              >
                Вставить токен
              </button>

              <button
                onClick={() => {
                  const url = prompt('Адрес вашего шлюза:', gatewayUrl);
                  if (url) setGatewayUrl(url);
                }}
                className="flex-1 h-11 rounded-2xl bg-[var(--s1)] text-[var(--tx)] text-xs font-semibold hover:bg-white/10 btn-spring-active cursor-pointer"
              >
                Изменить адрес шлюза
              </button>
            </div>
          </section>

          {/* Card: Скачивание */}
          <section
            className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-3 shadow-sm anim-rise"
            style={{ animationDelay: '0.04s' }}
          >
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Скачивание</h3>

            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'both', label: 'Везде' },
                { id: 'lib', label: 'В медиатеку' },
                { id: 'file', label: 'Файлом' },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => setDlLocation(m.id as any)}
                  className={`h-11 rounded-2xl text-xs font-semibold transition-all duration-300 btn-spring-active cursor-pointer ${
                    dlLocation === m.id
                      ? 'bg-[var(--p)] text-[var(--onp)] shadow-sm'
                      : 'bg-[var(--s1)] text-[var(--mu)]'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <p className="text-xs text-[var(--mu)] leading-relaxed">
              В медиатеке трек играет без интернета и лежит в разделе «Загрузки». Файл сохраняется в
              загрузки телефона. Audius качается напрямую. Для YouTube приложение пробует Cobalt,
              Piped, затем ищет этот же трек на Audius и в Яндекс Музыке.
            </p>
          </section>

          {/* Card: Cobalt */}
          <section
            className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-3 shadow-sm anim-rise"
            style={{ animationDelay: '0.08s' }}
          >
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">
              Cobalt для YouTube (необязательно)
            </h3>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => alert('Укажите адрес Cobalt')}
                className="h-11 rounded-2xl bg-[var(--s1)] text-[var(--tx)] text-xs font-semibold hover:bg-white/10 btn-spring-active cursor-pointer"
              >
                Указать адрес
              </button>

              <button
                onClick={() => alert('Ключ API Cobalt')}
                className="h-11 rounded-2xl bg-[var(--s1)] text-[var(--tx)] text-xs font-semibold hover:bg-white/10 btn-spring-active cursor-pointer"
              >
                Ключ API
              </button>
            </div>
          </section>

          {/* Card: Поиск по YouTube */}
          <section
            className="p-5 rounded-[28px] bg-[color-mix(in_srgb,var(--s1)_74%,transparent)] border border-white/5 space-y-3 shadow-sm anim-rise"
            style={{ animationDelay: '0.12s' }}
          >
            <h3 className="text-lg font-bold font-display text-[var(--tx)]">Поиск по YouTube</h3>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => alert('Подключение воркера')}
                className="h-11 rounded-2xl bg-[var(--s1)] text-[var(--tx)] text-xs font-semibold hover:bg-white/10 btn-spring-active cursor-pointer"
              >
                Свой воркер
              </button>

              <button
                onClick={() => alert('Сервер Piped')}
                className="h-11 rounded-2xl bg-[var(--s1)] text-[var(--tx)] text-xs font-semibold hover:bg-white/10 btn-spring-active cursor-pointer"
              >
                Сервер Piped
              </button>
            </div>

            <button
              onClick={() => alert('Ключ YouTube API')}
              className="w-full h-11 rounded-2xl bg-[var(--s1)] text-[var(--tx)] text-xs font-semibold hover:bg-white/10 btn-spring-active cursor-pointer"
            >
              Ключ YouTube API
            </button>
          </section>
        </div>
      )}
    </div>
  );
};
