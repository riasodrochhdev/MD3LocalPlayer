import { Track } from './player.ts';

type PlaybackListener = (isPlaying: boolean) => void;
type TimeListener = (currentTime: number, duration: number) => void;
type TrackEndListener = () => void;

class AudioEngine {
  private audio: HTMLAudioElement;
  private audioCtx: AudioContext | null = null;
  private synthGain: GainNode | null = null;
  private synthInterval: number | null = null;
  private isSynthetic: boolean = false;
  private synthCurrentTime: number = 0;
  private synthDuration: number = 160;

  private onPlaybackListeners: Set<PlaybackListener> = new Set();
  private onTimeListeners: Set<TimeListener> = new Set();
  private onEndListeners: Set<TrackEndListener> = new Set();
  private nextHandler: (() => void) | null = null;
  private prevHandler: (() => void) | null = null;

  constructor() {
    this.audio = new Audio();
    this.audio.preload = 'metadata';

    this.audio.addEventListener('play', () => {
      this.notifyPlayback(true);
      this.updateMediaSessionState(true);
    });

    this.audio.addEventListener('pause', () => {
      this.notifyPlayback(false);
      this.updateMediaSessionState(false);
    });

    this.audio.addEventListener('timeupdate', () => {
      if (!this.isSynthetic) {
        this.notifyTime(this.audio.currentTime, this.audio.duration || 0);
      }
    });

    this.audio.addEventListener('loadedmetadata', () => {
      if (!this.isSynthetic) {
        this.notifyTime(this.audio.currentTime, this.audio.duration || 0);
      }
    });

    this.audio.addEventListener('ended', () => {
      this.notifyPlayback(false);
      this.onEndListeners.forEach((fn) => fn());
    });

    this.setupMediaSession();
  }

  private setupMediaSession() {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return;

    try {
      navigator.mediaSession.setActionHandler('play', () => this.play());
      navigator.mediaSession.setActionHandler('pause', () => this.pause());
      navigator.mediaSession.setActionHandler('nexttrack', () => {
        if (this.nextHandler) this.nextHandler();
      });
      navigator.mediaSession.setActionHandler('previoustrack', () => {
        if (this.prevHandler) this.prevHandler();
      });
      navigator.mediaSession.setActionHandler('seekto', (details) => {
        if (details.seekTime != null) {
          this.seek(details.seekTime);
        }
      });
    } catch (_) {}
  }

  public setNavigationHandlers(onNext: () => void, onPrev: () => void) {
    this.nextHandler = onNext;
    this.prevHandler = onPrev;
  }

  public updateMediaSession(track: Track) {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return;

    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: track.title,
        artist: track.artist,
        album: track.album || 'Медиатека',
        artwork: [
          {
            src: track.cover || 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=512&auto=format&fit=crop&q=60',
            sizes: '512x512',
            type: 'image/png',
          },
        ],
      });
    } catch (_) {}
  }

  public updateMediaSessionState(isPlaying: boolean) {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return;
    try {
      navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';
    } catch (_) {}
  }

  public loadTrack(track: Track, autoPlay: boolean = true) {
    this.stopSynth();

    if (track.url) {
      // Real local audio file (Object URL or stream)
      this.isSynthetic = false;
      this.audio.src = track.url;
      this.updateMediaSession(track);
      if (autoPlay) {
        this.audio.play().catch(() => {});
      }
    } else {
      // Synthetic musical ambient track generator
      this.isSynthetic = true;
      this.synthCurrentTime = 0;
      this.synthDuration = track.dur || 160;
      this.updateMediaSession(track);
      if (autoPlay) {
        this.startSynth(track.hue || 280);
      }
    }
  }

  public play() {
    if (this.isSynthetic) {
      this.startSynth();
    } else {
      this.audio.play().catch(() => {});
    }
  }

  public pause() {
    if (this.isSynthetic) {
      this.pauseSynth();
    } else {
      this.audio.pause();
    }
  }

  public seek(seconds: number) {
    if (this.isSynthetic) {
      this.synthCurrentTime = Math.max(0, Math.min(seconds, this.synthDuration));
      this.notifyTime(this.synthCurrentTime, this.synthDuration);
    } else {
      if (isFinite(seconds)) {
        this.audio.currentTime = seconds;
      }
    }
  }

  public setVolume(volume: number) {
    const clamped = Math.max(0, Math.min(volume, 1));
    this.audio.volume = clamped;
    if (this.synthGain) {
      this.synthGain.gain.value = clamped * 0.12;
    }
  }

  public getVolume(): number {
    return this.audio.volume;
  }

  public getCurrentTime(): number {
    return this.isSynthetic ? this.synthCurrentTime : this.audio.currentTime || 0;
  }

  public getDuration(): number {
    return this.isSynthetic ? this.synthDuration : this.audio.duration || 0;
  }

  public isCurrentlyPlaying(): boolean {
    return this.isSynthetic ? this.synthInterval !== null : !this.audio.paused;
  }

  // --- Synthetic Ambient Music Generator for Demo Tracks ---
  private initAudioContext() {
    if (!this.audioCtx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.audioCtx = new AudioCtx();
        this.synthGain = this.audioCtx.createGain();
        this.synthGain.gain.value = (this.audio.volume || 1) * 0.12;
        this.synthGain.connect(this.audioCtx.destination);
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  private startSynth(seedHue: number = 280) {
    this.initAudioContext();
    if (this.synthInterval) return;

    this.notifyPlayback(true);
    this.updateMediaSessionState(true);

    const baseFreqs = [110, 130.81, 146.83, 164.81, 196.0, 220, 261.63];
    const baseFreq = baseFreqs[Math.floor((seedHue % 7))] || 146.83;

    // Play a gentle ambient rhythmic chord pulse
    this.playTone(baseFreq, 1.8, 'sine');
    this.playTone(baseFreq * 1.5, 1.8, 'triangle');

    this.synthInterval = window.setInterval(() => {
      this.synthCurrentTime += 1;
      this.notifyTime(this.synthCurrentTime, this.synthDuration);

      // Play soft harmonic notes every 2-4 seconds
      if (this.synthCurrentTime % 2 === 0 && this.audioCtx) {
        const intervalNote = baseFreq * [1, 1.2, 1.333, 1.5, 1.875][(this.synthCurrentTime / 2) % 5];
        this.playTone(intervalNote, 1.2, 'sine');
      }

      if (this.synthCurrentTime >= this.synthDuration) {
        this.pauseSynth();
        this.onEndListeners.forEach((fn) => fn());
      }
    }, 1000);
  }

  private playTone(freq: number, duration: number, type: OscillatorType) {
    if (!this.audioCtx || !this.synthGain) return;
    try {
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.audioCtx.currentTime);

      const now = this.audioCtx.currentTime;
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.exponentialRampToValueAtTime(0.18, now + 0.15);
      gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

      osc.connect(gain);
      gain.connect(this.synthGain);

      osc.start(now);
      osc.stop(now + duration + 0.1);
    } catch (_) {}
  }

  private pauseSynth() {
    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
    this.notifyPlayback(false);
    this.updateMediaSessionState(false);
  }

  private stopSynth() {
    this.pauseSynth();
    this.synthCurrentTime = 0;
  }

  // --- Listeners ---
  public addPlaybackListener(listener: PlaybackListener) {
    this.onPlaybackListeners.add(listener);
    return () => this.onPlaybackListeners.delete(listener);
  }

  public addTimeListener(listener: TimeListener) {
    this.onTimeListeners.add(listener);
    return () => this.onTimeListeners.delete(listener);
  }

  public addEndListener(listener: TrackEndListener) {
    this.onEndListeners.add(listener);
    return () => this.onEndListeners.delete(listener);
  }

  private notifyPlayback(isPlaying: boolean) {
    this.onPlaybackListeners.forEach((fn) => fn(isPlaying));
  }

  private notifyTime(current: number, dur: number) {
    this.onTimeListeners.forEach((fn) => fn(current, dur));
  }
}

export const audioEngine = new AudioEngine();
