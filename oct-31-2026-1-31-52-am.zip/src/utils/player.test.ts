import test from 'node:test';
import assert from 'node:assert/strict';
import { formatTime, pluralTracks, filterTracks, getNextTrackIndex, Track } from './player.ts';

test('formatTime formats seconds into mm:ss', () => {
  assert.equal(formatTime(0), '0:00');
  assert.equal(formatTime(65), '1:05');
  assert.equal(formatTime(160), '2:40');
  assert.equal(formatTime(367), '6:07');
});

test('pluralTracks handles Russian plural forms', () => {
  assert.equal(pluralTracks(1), '1 трек');
  assert.equal(pluralTracks(2), '2 трека');
  assert.equal(pluralTracks(4), '4 трека');
  assert.equal(pluralTracks(5), '5 треков');
  assert.equal(pluralTracks(11), '11 треков');
  assert.equal(pluralTracks(18), '18 треков');
  assert.equal(pluralTracks(21), '21 трек');
});

test('filterTracks searches by title, artist and album', () => {
  const tracks: Track[] = [
    { id: 1, key: '1', title: 'Вайбкод', artist: 'Ржавый бит', album: 'Single', dur: 160 },
    { id: 2, key: '2', title: 'Белый 500', artist: 'Нурминский', album: 'Альбом', dur: 204 },
  ];
  assert.equal(filterTracks(tracks, 'вайб').length, 1);
  assert.equal(filterTracks(tracks, 'нурмин').length, 1);
  assert.equal(filterTracks(tracks, 'нету').length, 0);
  assert.equal(filterTracks(tracks, '').length, 2);
});

test('parseAudioFileName parses artist and title', () => {
  import('./player.ts').then(({ parseAudioFileName }) => {
    assert.deepEqual(parseAudioFileName('Ржавый бит - Вайбкод.mp3'), {
      artist: 'Ржавый бит',
      title: 'Вайбкод',
    });
    assert.deepEqual(parseAudioFileName('track_name_only.wav'), {
      artist: 'Неизвестный исполнитель',
      title: 'track name only',
    });
  });
});

test('getNextTrackIndex handles standard, shuffle, and repeat modes', () => {
  assert.equal(getNextTrackIndex(0, 3, false, 0), 1);
  assert.equal(getNextTrackIndex(2, 3, false, 0), -1); // end of playlist
  assert.equal(getNextTrackIndex(2, 3, false, 1), 0); // repeat all
  assert.equal(getNextTrackIndex(1, 3, false, 2), 1); // repeat one
});

test('queue operations: add, play next, remove', async () => {
  const { addToQueue, playNextInQueue, removeFromQueue } = await import('./player.ts');
  let q = [1, 2, 3];
  q = addToQueue(q, 4);
  assert.deepEqual(q, [1, 2, 3, 4]);

  // Insert next after current index 0 (track 1)
  q = playNextInQueue(q, 0, 99);
  assert.deepEqual(q, [1, 99, 2, 3, 4]);

  // Remove track
  q = removeFromQueue(q, 99);
  assert.deepEqual(q, [1, 2, 3, 4]);
});
