export interface Track {
  id: number;
  key: string;
  title: string;
  artist: string;
  album: string;
  dur: number; // in seconds
  cover?: string;
  hue?: number;
  isFav?: boolean;
  isDownloaded?: boolean;
  url?: string;
}

export type ThemeName =
  | 'violet'
  | 'rose'
  | 'ocean'
  | 'mint'
  | 'sunset'
  | 'amoled'
  | 'mono'
  | 'monoblack'
  | 'light';

export const THEMES: { id: ThemeName; name: string; bg: string; color: string }[] = [
  { id: 'violet', name: 'Фиалка', bg: '#201b23', color: '#e8b9f2' },
  { id: 'rose', name: 'Роза', bg: '#221a1e', color: '#ffb1cc' },
  { id: 'ocean', name: 'Океан', bg: '#121b21', color: '#8fd3f4' },
  { id: 'mint', name: 'Мята', bg: '#131c17', color: '#9fe0b4' },
  { id: 'sunset', name: 'Закат', bg: '#201915', color: '#ffb87a' },
  { id: 'amoled', name: 'AMOLED', bg: '#000000', color: '#e8b9f2' },
  { id: 'mono', name: 'Моно', bg: '#151515', color: '#f0f0f0' },
  { id: 'monoblack', name: 'Моно AMOLED', bg: '#000000', color: '#ffffff' },
  { id: 'light', name: 'Светлая', bg: '#fbf1fb', color: '#7a4189' },
];

export function formatTime(seconds: number): string {
  if (!isFinite(seconds) || seconds < 0) return '0:00';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

export function pluralTracks(n: number): string {
  const rem10 = n % 10;
  const rem100 = n % 100;
  if (rem10 === 1 && rem100 !== 11) return `${n} трек`;
  if (rem10 >= 2 && rem10 <= 4 && (rem100 < 10 || rem100 >= 20)) return `${n} трека`;
  return `${n} треков`;
}

export function filterTracks(tracks: Track[], query: string): Track[] {
  const q = query.trim().toLowerCase();
  if (!q) return tracks;
  return tracks.filter(
    (t) =>
      t.title.toLowerCase().includes(q) ||
      t.artist.toLowerCase().includes(q) ||
      t.album.toLowerCase().includes(q)
  );
}

export function parseAudioFileName(fileName: string): { title: string; artist: string } {
  const base = fileName.replace(/\.[^.]+$/, '').replace(/_/g, ' ').trim();
  const sepIdx = base.indexOf(' - ');
  if (sepIdx > 0) {
    return {
      artist: base.slice(0, sepIdx).trim(),
      title: base.slice(sepIdx + 3).trim(),
    };
  }
  return {
    artist: 'Неизвестный исполнитель',
    title: base || 'Без названия',
  };
}

export function addToQueue(queue: number[], trackId: number): number[] {
  if (queue.includes(trackId)) return queue;
  return [...queue, trackId];
}

export function playNextInQueue(
  queue: number[],
  currentIndex: number,
  trackId: number
): number[] {
  const filtered = queue.filter((id) => id !== trackId);
  const insertIndex = currentIndex >= 0 ? currentIndex + 1 : 0;
  filtered.splice(insertIndex, 0, trackId);
  return filtered;
}

export function removeFromQueue(queue: number[], trackId: number): number[] {
  return queue.filter((id) => id !== trackId);
}

export function getNextTrackIndex(
  currentIndex: number,
  totalTracks: number,
  isShuffle: boolean,
  repeatMode: number // 0 = off, 1 = all, 2 = one
): number {
  if (totalTracks <= 0) return -1;
  if (repeatMode === 2) return currentIndex;
  if (isShuffle && totalTracks > 1) {
    let next = Math.floor(Math.random() * totalTracks);
    while (next === currentIndex) {
      next = Math.floor(Math.random() * totalTracks);
    }
    return next;
  }
  const next = currentIndex + 1;
  if (next >= totalTracks) {
    return repeatMode === 1 ? 0 : -1;
  }
  return next;
}
