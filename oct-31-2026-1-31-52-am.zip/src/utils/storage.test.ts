import test from 'node:test';
import assert from 'node:assert/strict';

// Simple polyfill for localStorage in node test environment
if (typeof globalThis.localStorage === 'undefined') {
  const store = new Map<string, string>();
  (globalThis as any).localStorage = {
    getItem: (k: string) => store.get(k) ?? null,
    setItem: (k: string, v: string) => store.set(k, v),
    removeItem: (k: string) => store.delete(k),
    clear: () => store.clear(),
  };
}

test('storage manages favorites, downloads, queue and custom tracks', async () => {
  const { storage } = await import('./storage.ts');

  // Favorites
  storage.saveFavorites(new Set([10, 20, 30]));
  const favs = storage.getFavorites();
  assert.equal(favs.has(10), true);
  assert.equal(favs.has(20), true);
  assert.equal(favs.has(999), false);

  // Downloads
  storage.saveDownloads(new Set([1, 5]));
  const dls = storage.getDownloads();
  assert.equal(dls.has(1), true);
  assert.equal(dls.has(5), true);
  assert.equal(dls.has(100), false);

  // Queue
  storage.saveQueue([3, 1, 2]);
  const q = storage.getQueue();
  assert.deepEqual(q, [3, 1, 2]);

  // Custom tracks
  storage.saveCustomTracks([
    {
      id: 101,
      key: 'test',
      title: 'Local Test Track',
      artist: 'Tester',
      album: 'Single',
      dur: 120,
      hue: 280,
      isFav: true,
      isDownloaded: true,
    },
  ]);
  const custom = storage.getCustomTracks();
  assert.equal(custom.length, 1);
  assert.equal(custom[0].title, 'Local Test Track');
});
