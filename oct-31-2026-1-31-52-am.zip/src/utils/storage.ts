import { Track } from './player.ts';

const FAV_STORAGE_KEY = 'mediateka_favs';
const DL_STORAGE_KEY = 'mediateka_dls';
const QUEUE_STORAGE_KEY = 'mediateka_queue';
const CUSTOM_TRACKS_KEY = 'mediateka_custom_tracks';

export const storage = {
  getFavorites(): Set<number> {
    try {
      const data = localStorage.getItem(FAV_STORAGE_KEY);
      return data ? new Set(JSON.parse(data)) : new Set([1, 2, 10, 12]);
    } catch {
      return new Set([1, 2, 10, 12]);
    }
  },

  saveFavorites(favs: Set<number>) {
    try {
      localStorage.setItem(FAV_STORAGE_KEY, JSON.stringify([...favs]));
    } catch {}
  },

  getDownloads(): Set<number> {
    try {
      const data = localStorage.getItem(DL_STORAGE_KEY);
      return data ? new Set(JSON.parse(data)) : new Set([1, 2]);
    } catch {
      return new Set([1, 2]);
    }
  },

  saveDownloads(dls: Set<number>) {
    try {
      localStorage.setItem(DL_STORAGE_KEY, JSON.stringify([...dls]));
    } catch {}
  },

  getQueue(): number[] {
    try {
      const data = localStorage.getItem(QUEUE_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveQueue(queue: number[]) {
    try {
      localStorage.setItem(QUEUE_STORAGE_KEY, JSON.stringify(queue));
    } catch {}
  },

  getCustomTracks(): Track[] {
    try {
      const data = localStorage.getItem(CUSTOM_TRACKS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveCustomTracks(tracks: Track[]) {
    try {
      // Don't save transient object URLs directly in json
      const serializable = tracks.map((t) => ({
        id: t.id,
        key: t.key,
        title: t.title,
        artist: t.artist,
        album: t.album,
        dur: t.dur,
        hue: t.hue,
        isFav: t.isFav,
        isDownloaded: t.isDownloaded,
      }));
      localStorage.setItem(CUSTOM_TRACKS_KEY, JSON.stringify(serializable));
    } catch {}
  },
};
