package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AmbientBackground
import com.example.ui.components.BottomNavBar
import com.example.ui.components.MiniPlayer
import com.example.ui.components.PlayerBottomSheet
import com.example.ui.components.SnowOverlay
import com.example.ui.components.TrackContextMenu
import com.example.ui.screens.ArtistScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AllThemes
import com.example.ui.theme.MediatekaTheme
import com.example.ui.theme.ThemeViolet
import com.example.viewmodel.PlayerUiViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MediatekaApp()
    }
  }
}

@Composable
fun MediatekaApp(viewModel: PlayerUiViewModel = viewModel()) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val context = LocalContext.current

  val activeTheme = remember(uiState.settings.themeId) {
    AllThemes.find { it.id == uiState.settings.themeId } ?: ThemeViolet
  }

  val animationsEnabled = uiState.settings.alwaysAnimations

  // Back handler for artist detail or sheet overlay
  BackHandler(enabled = uiState.isPlayerSheetOpen || uiState.activeArtist != null) {
    if (uiState.isPlayerSheetOpen) {
      viewModel.closePlayerSheet()
    } else if (uiState.activeArtist != null) {
      viewModel.closeArtist()
    }
  }

  LaunchedEffect(uiState.toastMessage) {
    uiState.toastMessage?.let { msg ->
      Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
      viewModel.clearToast()
    }
  }

  MediatekaTheme(colors = activeTheme) {
    Box(modifier = Modifier.fillMaxSize()) {
      // Ambient background mesh canvas
      AmbientBackground(
        bgType = uiState.settings.bgType,
        currentTrack = uiState.currentTrack,
        bgColorByCover = uiState.settings.bgColorByCover,
        bgMoveOnlyWhilePlaying = uiState.settings.bgMoveOnlyWhilePlaying,
        isPlaying = uiState.isPlaying,
        bgSpeed = uiState.settings.bgSpeed,
        bgIntensity = uiState.settings.bgIntensity
      )

      // Snowflakes overlay when enabled in Settings
      SnowOverlay(
        enabled = uiState.settings.snowEnabled,
        amount = uiState.settings.snowAmount
      )

      Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        modifier = Modifier.fillMaxSize()
      ) { innerPadding ->
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
        ) {
          // Main content views
          if (uiState.activeArtist != null) {
            ArtistScreen(
              artist = uiState.activeArtist!!,
              tracks = uiState.tracks,
              currentTrack = uiState.currentTrack,
              favIconStyle = uiState.settings.favIcon,
              onBackClick = { viewModel.closeArtist() },
              onTrackClick = { viewModel.playTrack(it) },
              onTrackLongClick = { viewModel.openContextMenu(it) },
              onPlayArtist = {
                uiState.tracks.firstOrNull { it.artist.contains(uiState.activeArtist!!.name, true) }
                  ?.let { viewModel.playTrack(it) }
              },
              onShuffleArtist = {
                viewModel.toggleShuffle()
                uiState.tracks.filter { it.artist.contains(uiState.activeArtist!!.name, true) }
                  .shuffled()
                  .firstOrNull()
                  ?.let { viewModel.playTrack(it) }
              },
              onFavoriteToggle = { viewModel.toggleFavorite(it) },
              onDownloadClick = { viewModel.showToast("Скачано в загрузки") },
              onSelectRelatedArtist = { viewModel.openArtist(it) },
              enabledAnimations = animationsEnabled
            )
          } else {
            when (uiState.currentTab) {
              "home" -> HomeScreen(
                tracks = uiState.tracks,
                recommendations = uiState.recommendations,
                currentTrack = uiState.currentTrack,
                isPlaying = uiState.isPlaying,
                favIconStyle = uiState.settings.favIcon,
                onTrackClick = { viewModel.playTrack(it) },
                onTrackLongClick = { viewModel.openContextMenu(it) },
                onPlayClick = { viewModel.togglePlayPause() },
                onDiceClick = {
                  val randomTrack = uiState.tracks.randomOrNull()
                  if (randomTrack != null) {
                    viewModel.toggleShuffle()
                    viewModel.playTrack(randomTrack)
                  }
                },
                onMixClick = {
                  viewModel.showToast("Собираю микс…")
                  val randomTrack = uiState.tracks.randomOrNull()
                  if (randomTrack != null) viewModel.playTrack(randomTrack)
                },
                onRefreshRecs = { viewModel.showToast("Обновляю ленту…") },
                onTuneRecs = { viewModel.setTab("settings") },
                onAddFolderClick = { viewModel.showToast("Добавить папку") },
                onAddFilesClick = { viewModel.showToast("Добавить файлы") },
                onAudioFilesPicked = { uris -> viewModel.addPickedAudioFiles(uris) },
                onFavoritesTileClick = {
                  viewModel.setLibraryFilter("fav")
                  viewModel.setTab("lib")
                },
                onDownloadsTileClick = {
                  viewModel.setLibraryFilter("dl")
                  viewModel.setTab("lib")
                },
                onFavoriteToggle = { viewModel.toggleFavorite(it) },
                onDownloadClick = { viewModel.downloadTrack(it) },
                enabledAnimations = animationsEnabled
              )

              "search" -> SearchScreen(
                query = uiState.searchQuery,
                recentQueries = uiState.recentQueries,
                tracks = uiState.tracks,
                onlineSearchResults = uiState.onlineSearchResults,
                isSearchingOnline = uiState.isSearchingOnline,
                currentTrack = uiState.currentTrack,
                favIconStyle = uiState.settings.favIcon,
                onQueryChange = { viewModel.setSearchQuery(it) },
                onClearRecentQueries = { viewModel.clearRecentQueries() },
                onTrackClick = { viewModel.playTrack(it) },
                onTrackLongClick = { viewModel.openContextMenu(it) },
                onFavoriteToggle = { viewModel.toggleFavorite(it) },
                onDownloadClick = { viewModel.downloadTrack(it) },
                enabledAnimations = animationsEnabled
              )

              "lib" -> LibraryScreen(
                tracks = uiState.tracks,
                currentTrack = uiState.currentTrack,
                currentFilter = uiState.libraryFilter,
                favIconStyle = uiState.settings.favIcon,
                onFilterChange = { viewModel.setLibraryFilter(it) },
                onTrackClick = { viewModel.playTrack(it) },
                onTrackLongClick = { viewModel.openContextMenu(it) },
                onFavoriteToggle = { viewModel.toggleFavorite(it) },
                onDownloadClick = { viewModel.downloadTrack(it) },
                onDeleteClick = { viewModel.deleteTrack(it) },
                onAddMusicClick = { viewModel.showToast("Выберите файлы") },
                onAudioFilesPicked = { uris -> viewModel.addPickedAudioFiles(uris) },
                onArtistClick = { viewModel.openArtist(it) },
                enabledAnimations = animationsEnabled
              )

              "settings" -> SettingsScreen(
                settings = uiState.settings,
                activeTab = uiState.settingsTab,
                onTabChange = { viewModel.setSettingsTab(it) },
                onThemeSelect = { viewModel.setTheme(it) },
                onGlassSelect = { viewModel.setGlassStyle(it) },
                onSnowToggle = { viewModel.toggleSnow() },
                onSnowAmountSelect = { viewModel.setSnowAmount(it) },
                onFavIconSelect = { viewModel.setFavIcon(it) },
                onVibrationToggle = { viewModel.toggleVibration() },
                onAnimationsToggle = { viewModel.toggleAnimations() },
                onBgTypeSelect = { viewModel.setBgType(it) },
                onBgColorByCoverToggle = { viewModel.toggleBgColorByCover() },
                onBgMoveOnlyPlayingToggle = { viewModel.toggleBgMoveOnlyPlaying() },
                onBgSpeedSelect = { viewModel.setBgSpeed(it) },
                onBgIntensitySelect = { viewModel.setBgIntensity(it) },
                onFeedLanguageSelect = { viewModel.setFeedLanguage(it) },
                onAddMyArtist = { viewModel.addMyArtist(it) },
                onRemoveMyArtist = { viewModel.removeMyArtist(it) },
                onTracksPerArtistSelect = { viewModel.setTracksPerArtist(it) },
                onFeedSizeSelect = { viewModel.setFeedSize(it) },
                onFeedAutoPlayToggle = { viewModel.toggleFeedAutoPlay() },
                onFeedAutoScrollToggle = { viewModel.toggleFeedAutoScroll() },
                onDownloadDestSelect = { viewModel.setDownloadDestination(it) },
                onShowToast = { viewModel.showToast(it) },
                enabledAnimations = animationsEnabled
              )
            }
          }
        }
      }

      // Overlay 1: MiniPlayer
      if (uiState.currentTrack != null && !uiState.isPlayerSheetOpen) {
        val progress = if (uiState.currentTrack!!.durationSeconds > 0) {
          uiState.currentPositionSeconds.toFloat() / uiState.currentTrack!!.durationSeconds
        } else 0f

        MiniPlayer(
          track = uiState.currentTrack!!,
          isPlaying = uiState.isPlaying,
          progress = progress,
          glassStyle = uiState.settings.glassStyle,
          onPlayPauseClick = { viewModel.togglePlayPause() },
          onNextClick = { viewModel.nextTrack() },
          onPlayerClick = { viewModel.openPlayerSheet() },
          enabledAnimations = animationsEnabled,
          modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(bottom = 80.dp)
            .navigationBarsPadding()
        )
      }

      // Overlay 2: Floating Bottom Navigation Bar
      BottomNavBar(
        currentTab = uiState.currentTab,
        onTabSelected = { viewModel.setTab(it) },
        glassStyle = uiState.settings.glassStyle,
        coverHue = uiState.currentTrack?.coverHue?.toFloat() ?: 260f,
        enabledAnimations = animationsEnabled,
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .navigationBarsPadding()
      )

      // Overlay 3: Fullscreen Player Sheet
      PlayerBottomSheet(
        visible = uiState.isPlayerSheetOpen,
        track = uiState.currentTrack,
        isPlaying = uiState.isPlaying,
        currentPositionSeconds = uiState.currentPositionSeconds,
        isShuffle = uiState.isShuffle,
        repeatMode = uiState.repeatMode,
        coverShapeIndex = uiState.coverShapeIndex,
        favIconStyle = uiState.settings.favIcon,
        volume = uiState.currentVolume,
        onVolumeChange = { viewModel.setVolume(it) },
        onClose = { viewModel.closePlayerSheet() },
        onPlayPause = { viewModel.togglePlayPause() },
        onNext = { viewModel.nextTrack() },
        onPrev = { viewModel.previousTrack() },
        onShuffle = { viewModel.toggleShuffle() },
        onRepeat = { viewModel.cycleRepeat() },
        onCoverShapeCycle = { viewModel.cycleCoverShape() },
        onFavoriteToggle = {
          uiState.currentTrack?.let { viewModel.toggleFavorite(it.id) }
        },
        onDownload = {
          uiState.currentTrack?.let { viewModel.downloadTrack(it) }
        },
        onArtistClick = { artistName ->
          viewModel.closePlayerSheet()
          viewModel.openArtist(artistName)
        },
        onSeek = { seconds -> viewModel.seekTo(seconds) },
        enabledAnimations = animationsEnabled
      )

      // Overlay 4: Context Menu
      TrackContextMenu(
        track = uiState.contextMenuTrack,
        onDismiss = { viewModel.closeContextMenu() },
        onPlayNext = {
          uiState.contextMenuTrack?.let { viewModel.playNext(it) }
        },
        onAddToQueue = {
          uiState.contextMenuTrack?.let { viewModel.addToQueue(it) }
        },
        onToggleFavorite = {
          uiState.contextMenuTrack?.let { viewModel.toggleFavorite(it.id) }
        },
        onDownload = {
          uiState.contextMenuTrack?.let { viewModel.downloadTrack(it) }
        },
        onGoToArtist = { artistName ->
          viewModel.openArtist(artistName)
        },
        onDelete = {
          uiState.contextMenuTrack?.let { viewModel.deleteTrack(it) }
        }
      )
    }
  }
}
