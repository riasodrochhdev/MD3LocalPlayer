package com.example.api

import com.example.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object OnlineMusicRepository {
  private val client = OkHttpClient.Builder()
    .connectTimeout(8, TimeUnit.SECONDS)
    .readTimeout(8, TimeUnit.SECONDS)
    .build()

  private const val AUDIUS_APP_NAME = "MD3Mediateka"
  private const val AUDIUS_BASE_URL = "https://discoveryprovider.audius.co/v1"

  suspend fun fetchTrendingTracks(): List<Track> = withContext(Dispatchers.IO) {
    val results = mutableListOf<Track>()
    
    // 1. Fetch from Audius Trending
    try {
      val request = Request.Builder()
        .url("$AUDIUS_BASE_URL/tracks/trending?app_name=$AUDIUS_APP_NAME&limit=15")
        .header("User-Agent", "MD3MediatekaAndroid/1.0")
        .build()

      client.newCall(request).execute().use { response ->
        if (response.isSuccessful) {
          val bodyString = response.body?.string()
          if (!bodyString.isNull_orEmpty()) {
            val json = JSONObject(bodyString)
            val dataArray = json.optJSONArray("data")
            if (dataArray != null) {
              for (i in 0 until dataArray.length()) {
                val item = dataArray.optJSONObject(i) ?: continue
                val track = parseAudiusTrack(item)
                if (track != null) {
                  results.add(track)
                }
              }
            }
          }
        }
      }
    } catch (e: Exception) {
      e.printStackTrace()
    }

    // 2. Fetch from YouTube Music / Piped
    try {
      val ytTracks = fetchYouTubeMusicTracks("trending music")
      results.addAll(ytTracks)
    } catch (e: Exception) {
      e.printStackTrace()
    }

    return@withContext results
  }

  suspend fun searchOnlineTracks(query: String): List<Track> = withContext(Dispatchers.IO) {
    if (query.isBlank()) return@withContext emptyList()
    val results = mutableListOf<Track>()

    // 1. Search Audius
    try {
      val url = "$AUDIUS_BASE_URL/tracks/search?query=${java.net.URLEncoder.encode(query, "UTF-8")}&app_name=$AUDIUS_APP_NAME&limit=10"
      val request = Request.Builder()
        .url(url)
        .header("User-Agent", "MD3MediatekaAndroid/1.0")
        .build()

      client.newCall(request).execute().use { response ->
        if (response.isSuccessful) {
          val bodyString = response.body?.string()
          if (!bodyString.isNull_orEmpty()) {
            val json = JSONObject(bodyString)
            val dataArray = json.optJSONArray("data")
            if (dataArray != null) {
              for (i in 0 until dataArray.length()) {
                val item = dataArray.optJSONObject(i) ?: continue
                val track = parseAudiusTrack(item)
                if (track != null) {
                  results.add(track)
                }
              }
            }
          }
        }
      }
    } catch (e: Exception) {
      e.printStackTrace()
    }

    // 2. Search YouTube Music / Piped
    try {
      val ytTracks = fetchYouTubeMusicTracks(query)
      results.addAll(ytTracks)
    } catch (e: Exception) {
      e.printStackTrace()
    }

    return@withContext results
  }

  private fun parseAudiusTrack(item: JSONObject): Track? {
    val idStr = item.optString("id")
    if (idStr.isEmpty()) return null
    val title = item.optString("title", "Без названия")
    val userObj = item.optJSONObject("user")
    val artistName = userObj?.optString("name", "Audius Artist") ?: "Audius Artist"
    val duration = item.optInt("duration", 180)

    val artworkObj = item.optJSONObject("artwork")
    val coverUrl = artworkObj?.optString("480x480")
      ?: artworkObj?.optString("150x150")
      ?: "https://audius.co/static/media/audiusSymbol.4402a550.png"

    // Numeric ID based on hash of string ID
    val numericId = (idStr.hashCode().toLong() and 0x7FFFFFFF) + 50000L
    val streamUrl = "$AUDIUS_BASE_URL/tracks/$idStr/stream?app_name=$AUDIUS_APP_NAME"

    return Track(
      id = numericId,
      title = title,
      artist = artistName,
      album = "Audius",
      durationSeconds = duration,
      coverHue = (numericId % 360).toInt(),
      coverUrl = streamUrl // Used by playerManager or trackUriMap
    )
  }

  private fun fetchYouTubeMusicTracks(query: String): List<Track> {
    val list = mutableListOf<Track>()
    try {
      val url = "https://pipedapi.kavin.rocks/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}&filter=music_songs"
      val request = Request.Builder()
        .url(url)
        .header("User-Agent", "MD3MediatekaAndroid/1.0")
        .build()

      client.newCall(request).execute().use { response ->
        if (response.isSuccessful) {
          val bodyString = response.body?.string()
          if (!bodyString.isNull_orEmpty()) {
            val json = JSONObject(bodyString)
            val items = json.optJSONArray("items")
            if (items != null) {
              for (i in 0 until items.length().coerceAtMost(8)) {
                val item = items.optJSONObject(i) ?: continue
                val urlPath = item.optString("url", "")
                val videoId = urlPath.replace("/watch?v=", "")
                if (videoId.isEmpty()) continue

                val title = item.optString("title", "YouTube Track")
                val uploader = item.optString("uploaderName", "YouTube Music")
                val duration = item.optInt("duration", 210)
                val thumbnail = item.optString("thumbnail", "")

                val numericId = (videoId.hashCode().toLong() and 0x7FFFFFFF) + 90000L
                // Audio stream URL via piped / invidious stream proxy or fallback
                val audioStreamUrl = "https://pipedapi.kavin.rocks/streams/$videoId"

                list.add(
                  Track(
                    id = numericId,
                    title = title,
                    artist = uploader,
                    album = "YouTube Music",
                    durationSeconds = duration,
                    coverHue = (numericId % 360).toInt(),
                    coverUrl = thumbnail.ifEmpty { audioStreamUrl }
                  )
                )
              }
            }
          }
        }
      }
    } catch (_: Exception) {}
    return list
  }
}

private fun String?.isNull_orEmpty(): Boolean = this == null || this.isEmpty()
