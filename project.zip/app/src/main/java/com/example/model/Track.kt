package com.example.model

data class Track(
  val id: Long,
  val title: String,
  val artist: String,
  val album: String = "Медиатека",
  val durationSeconds: Int = 160,
  val coverHue: Int = 280,
  val coverUrl: String? = null,
  val isFavorite: Boolean = false,
  val isDownloaded: Boolean = false
) {
  val formattedDuration: String
    get() {
      val minutes = durationSeconds / 60
      val seconds = durationSeconds % 60
      return "%d:%02d".format(minutes, seconds)
    }
}

data class Artist(
  val id: String,
  val name: String,
  val monthlyListeners: String = "124 тыс. слушателей в месяц",
  val tracksCount: Int = 18,
  val bio: String = "Российский исполнитель, музыкант и продюсер. Вайб, драйв и атмосферный бит.",
  val avatarUrl: String? = null
)
