package com.example.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.model.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PlaybackState(
  val currentTrack: Track? = null,
  val isPlaying: Boolean = false,
  val currentPositionMs: Long = 0L,
  val durationMs: Long = 0L,
  val volume: Float = 1.0f
)

class AudioPlayerManager(private val context: Context) {
  private var player: ExoPlayer? = null
  private val coroutineScope = CoroutineScope(Dispatchers.Main + Job())
  private var positionUpdateJob: Job? = null

  private val _playbackState = MutableStateFlow(PlaybackState())
  val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

  init {
    initPlayer()
  }

  private fun initPlayer() {
    val exoPlayer = ExoPlayer.Builder(context.applicationContext)
      .setAudioAttributes(
        AudioAttributes.Builder()
          .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
          .setUsage(C.USAGE_MEDIA)
          .build(),
        true
      )
      .setHandleAudioBecomingNoisy(true)
      .build()

    exoPlayer.addListener(object : Player.Listener {
      override fun onIsPlayingChanged(isPlaying: Boolean) {
        _playbackState.update { it.copy(isPlaying = isPlaying) }
        if (isPlaying) {
          startPositionTracking()
        } else {
          stopPositionTracking()
        }
      }

      override fun onPlaybackStateChanged(state: Int) {
        if (state == Player.STATE_READY) {
          val dur = player?.duration ?: 0L
          _playbackState.update {
            it.copy(durationMs = if (dur > 0) dur else it.durationMs)
          }
        }
      }
    })

    player = exoPlayer
  }

  fun playTrack(track: Track, uriString: String? = null) {
    val exoPlayer = player ?: return
    val mediaUri = when {
      !uriString.isNullOrEmpty() -> Uri.parse(uriString)
      !track.coverUrl.isNullOrEmpty() && track.coverUrl.startsWith("content://") -> Uri.parse(track.coverUrl)
      else -> null
    }

    _playbackState.update {
      it.copy(
        currentTrack = track,
        currentPositionMs = 0L,
        durationMs = track.durationSeconds * 1000L
      )
    }

    if (mediaUri != null) {
      val mediaItem = MediaItem.Builder()
        .setUri(mediaUri)
        .setMediaMetadata(
          MediaMetadata.Builder()
            .setTitle(track.title)
            .setArtist(track.artist)
            .setAlbumTitle(track.album)
            .build()
        )
        .build()

      exoPlayer.setMediaItem(mediaItem)
      exoPlayer.prepare()
      exoPlayer.play()
    }
  }

  fun togglePlayPause() {
    val exoPlayer = player ?: return
    if (exoPlayer.isPlaying) {
      exoPlayer.pause()
    } else {
      exoPlayer.play()
    }
  }

  fun seekToMs(positionMs: Long) {
    val exoPlayer = player ?: return
    exoPlayer.seekTo(positionMs)
    _playbackState.update { it.copy(currentPositionMs = positionMs) }
  }

  fun setVolume(volume: Float) {
    val clampedVol = volume.coerceIn(0f, 1f)
    player?.volume = clampedVol
    _playbackState.update { it.copy(volume = clampedVol) }
  }

  private fun startPositionTracking() {
    positionUpdateJob?.cancel()
    positionUpdateJob = coroutineScope.launch {
      while (true) {
        player?.let { p ->
          _playbackState.update {
            it.copy(
              currentPositionMs = p.currentPosition.coerceAtLeast(0L),
              durationMs = if (p.duration > 0) p.duration else it.durationMs
            )
          }
        }
        delay(500L)
      }
    }
  }

  private fun stopPositionTracking() {
    positionUpdateJob?.cancel()
    positionUpdateJob = null
  }

  fun release() {
    stopPositionTracking()
    player?.release()
    player = null
  }
}
