package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EaseEasing
import com.example.ui.theme.SpringEasing
import com.example.ui.theme.mediatekaColors
import com.example.ui.theme.pressScale

data class NavItem(
  val id: String,
  val label: String,
  val icon: ImageVector
)

@Composable
fun BottomNavBar(
  currentTab: String,
  onTabSelected: (String) -> Unit,
  glassStyle: String = "blur", // "off", "blur"
  coverHue: Float = 260f,
  modifier: Modifier = Modifier,
  enabledAnimations: Boolean = true
) {
  val colors = MaterialTheme.mediatekaColors
  val items = listOf(
    NavItem("home", "Главная", Icons.Default.Home),
    NavItem("search", "Поиск", Icons.Default.Search),
    NavItem("lib", "Медиатека", Icons.Default.LibraryMusic),
    NavItem("settings", "Настройки", Icons.Default.Tune)
  )

  val entranceProgress = remember { Animatable(0f) }
  LaunchedEffect(Unit) {
    if (enabledAnimations) {
      entranceProgress.animateTo(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 600, easing = SpringEasing)
      )
    } else {
      entranceProgress.snapTo(1f)
    }
  }

  val shape = RoundedCornerShape(36.dp)
  val isBlur = glassStyle != "off"

  // Dynamic color from track cover hue, smoothly animated when tracks change
  val targetTrackTint = remember(coverHue) {
    Color.hsl(hue = (coverHue % 360f + 360f) % 360f, saturation = 0.55f, lightness = 0.28f)
  }
  val animatedTrackTint by animateColorAsState(
    targetValue = targetTrackTint,
    animationSpec = tween(durationMillis = 600, easing = EaseEasing),
    label = "navTrackTint"
  )

  Box(
    modifier = modifier
      .padding(horizontal = 16.dp, vertical = 12.dp)
      .graphicsLayer {
        val p = entranceProgress.value
        alpha = p
        scaleX = 0.9f + (0.1f * p)
        scaleY = 0.9f + (0.1f * p)
        translationY = (1f - p) * 30.dp.toPx()
      },
    contentAlignment = Alignment.Center
  ) {
    // Rich smoked glass container that smoothly follows cover color
    Box(
      modifier = Modifier
        .matchParentSize()
        .shadow(22.dp, shape, spotColor = animatedTrackTint)
        .clip(shape)
        .background(
          if (isBlur) {
            Brush.verticalGradient(
              colors = listOf(
                animatedTrackTint.copy(alpha = 0.55f),
                Color(0xFA171224),
                Color(0xFD0F0A18)
              )
            )
          } else {
            SolidColor(Color(0xFF1F192C))
          }
        )
        .border(
          width = 1.2.dp,
          brush = Brush.horizontalGradient(
            colors = listOf(
              animatedTrackTint.copy(alpha = 0.75f),
              Color(0x4DFFFFFF),
              animatedTrackTint.copy(alpha = 0.50f)
            )
          ),
          shape = shape
        )
    )

    Row(
      modifier = Modifier
        .padding(6.dp)
        .animateContentSize(
          animationSpec = tween(
            durationMillis = if (enabledAnimations) 400 else 0,
            easing = EaseEasing
          )
        ),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      items.forEach { item ->
        val selected = item.id == currentTab
        NavTabButton(
          item = item,
          selected = selected,
          onClick = { onTabSelected(item.id) },
          enabledAnimations = enabledAnimations
        )
      }
    }
  }
}

@Composable
private fun NavTabButton(
  item: NavItem,
  selected: Boolean,
  onClick: () -> Unit,
  enabledAnimations: Boolean
) {
  val colors = MaterialTheme.mediatekaColors

  val targetBg = if (selected) colors.pc else Color.Transparent
  val animatedBg by animateColorAsState(
    targetValue = targetBg,
    animationSpec = tween(
      durationMillis = if (enabledAnimations) 350 else 0,
      easing = EaseEasing
    ),
    label = "navBg"
  )

  val targetContentColor = if (selected) colors.onpc else colors.mu
  val animatedContentColor by animateColorAsState(
    targetValue = targetContentColor,
    animationSpec = tween(
      durationMillis = if (enabledAnimations) 300 else 0,
      easing = EaseEasing
    ),
    label = "navContentColor"
  )

  Row(
    modifier = Modifier
      .testTag("nav_tab_${item.id}")
      .height(56.dp)
      .widthIn(min = 56.dp)
      .clip(RoundedCornerShape(28.dp))
      .background(animatedBg)
      .pressScale(
        pressedScale = 0.92f,
        durationMillis = 300,
        easing = SpringEasing,
        enabled = enabledAnimations,
        onClick = onClick
      )
      .padding(horizontal = if (selected) 18.dp else 16.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.Center
  ) {
    Icon(
      imageVector = item.icon,
      contentDescription = item.label,
      tint = animatedContentColor,
      modifier = Modifier.size(24.dp)
    )

    AnimatedVisibility(
      visible = selected,
      enter = fadeIn(
        animationSpec = tween(
          durationMillis = if (enabledAnimations) 300 else 0,
          easing = EaseEasing
        )
      ),
      exit = fadeOut(
        animationSpec = tween(
          durationMillis = if (enabledAnimations) 200 else 0,
          easing = EaseEasing
        )
      )
    ) {
      Text(
        text = item.label,
        color = animatedContentColor,
        style = MaterialTheme.typography.labelLarge.copy(
          fontWeight = FontWeight.SemiBold,
          fontSize = 14.sp
        ),
        modifier = Modifier.padding(start = 8.dp),
        maxLines = 1
      )
    }
  }
}
