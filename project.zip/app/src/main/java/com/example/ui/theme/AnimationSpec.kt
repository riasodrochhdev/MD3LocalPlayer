package com.example.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput

// Exact curves from CSS:
// var(--ease): cubic-bezier(.2, .8, .2, 1)
val EaseEasing: Easing = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1.0f)

// var(--sp): cubic-bezier(.34, 1.56, .64, 1)
val SpringEasing: Easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1.0f)

@Composable
fun Modifier.pressScale(
  pressedScale: Float = 0.9f,
  durationMillis: Int = 280,
  easing: Easing = SpringEasing,
  enabled: Boolean = true,
  onClick: (() -> Unit)? = null
): Modifier {
  if (!enabled) {
    return if (onClick != null) this.clickable(onClick = onClick) else this
  }

  var isPressed by remember { mutableStateOf(false) }
  val scale by animateFloatAsState(
    targetValue = if (isPressed) pressedScale else 1f,
    animationSpec = tween(durationMillis = durationMillis, easing = easing),
    label = "pressScale"
  )

  return this
    .graphicsLayer {
      scaleX = scale
      scaleY = scale
    }
    .pointerInput(onClick) {
      awaitPointerEventScope {
        while (true) {
          val down = awaitFirstDown(false)
          isPressed = true
          val up = waitForUpOrCancellation()
          isPressed = false
          if (up != null && onClick != null) {
            onClick()
          }
        }
      }
    }
}
