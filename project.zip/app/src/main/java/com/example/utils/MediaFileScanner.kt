package com.example.utils

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.example.model.Track
import java.util.Locale

object MediaFileScanner {

  fun scanDeviceAudioFiles(context: Context): List<Pair<Track, Uri>> {
    val resultList = mutableListOf<Pair<Track, Uri>>()
    val resolver: ContentResolver = context.contentResolver

    val projection = arrayOf(
      MediaStore.Audio.Media._ID,
      MediaStore.Audio.Media.TITLE,
      MediaStore.Audio.Media.ARTIST,
      MediaStore.Audio.Media.ALBUM,
      MediaStore.Audio.Media.DURATION,
      MediaStore.Audio.Media.DATA
    )

    val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
    val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

    try {
      resolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
        projection,
        selection,
        null,
        sortOrder
      )?.use { cursor ->
        val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val albumColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

        var idCounter = 1000L

        while (cursor.moveToNext()) {
          val mediaId = cursor.getLong(idColumn)
          val title = cursor.getString(titleColumn) ?: "Без названия"
          val artist = cursor.getString(artistColumn) ?: "Неизвестный исполнитель"
          val album = cursor.getString(albumColumn) ?: "Медиатека"
          val durationMs = cursor.getInt(durationColumn)

          val contentUri = Uri.withAppendedPath(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            mediaId.toString()
          )

          val hue = (title.hashCode() and 0x7FFFFFFF) % 360

          val track = Track(
            id = idCounter++,
            title = title,
            artist = if (artist == "<unknown>") "Неизвестный исполнитель" else artist,
            album = album,
            durationSeconds = (durationMs / 1000).coerceAtLeast(1),
            coverHue = hue,
            coverUrl = contentUri.toString(),
            isFavorite = false,
            isDownloaded = true
          )

          resultList.add(Pair(track, contentUri))
        }
      }
    } catch (e: Exception) {
      e.printStackTrace()
    }

    return resultList
  }

  fun parseUriToTrack(context: Context, uri: Uri, idStart: Long): Pair<Track, Uri> {
    var title = "Новый трек"
    var artist = "Неизвестный исполнитель"
    var sizeBytes = 0L

    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
      val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
      val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
      if (cursor.moveToFirst()) {
        if (nameIndex != -1) {
          val displayName = cursor.getString(nameIndex) ?: ""
          val cleanName = displayName.replace(Regex("\\.(mp3|m4a|flac|wav|ogg|opus|aac)$", RegexOption.IGNORE_CASE), "")
          if (cleanName.contains(" - ")) {
            val parts = cleanName.split(" - ", limit = 2)
            artist = parts[0].trim()
            title = parts[1].trim()
          } else {
            title = cleanName
          }
        }
      }
    }

    val hue = (title.hashCode() and 0x7FFFFFFF) % 360

    val track = Track(
      id = idStart,
      title = title,
      artist = artist,
      album = "Загрузки",
      durationSeconds = 180,
      coverHue = hue,
      coverUrl = uri.toString(),
      isFavorite = false,
      isDownloaded = true
    )

    return Pair(track, uri)
  }
}
