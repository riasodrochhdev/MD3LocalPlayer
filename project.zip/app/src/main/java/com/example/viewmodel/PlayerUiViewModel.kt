package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.OnlineMusicRepository
import com.example.db.MediatekaDatabase
import com.example.db.TrackRepository
import com.example.db.toEntity
import com.example.model.Artist
import com.example.model.SettingsState
import com.example.model.TestData
import com.example.model.Track
import com.example.player.AudioPlayerManager
import com.example.utils.MediaFileScanner
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MediatekaUiState(
  val currentTab: String = "home", // "home", "search", "lib", "settings"
  val activeArtist: Artist? = null,
  val tracks: List<Track> = TestData.initialTracks,
  val recommendations: List<Track> = TestData.recommendations,
  val onlineSearchResults: List<Track> = emptyList(),
  val isSearchingOnline: Boolean = false,
  val queue: List<Track> = emptyList(),
  val currentTrack: Track? = TestData.initialTracks.firstOrNull(),
  val isPlaying: Boolean = false,
  val currentPositionSeconds: Int = 0,
  val currentVolume: Float = 1.0f,
  val isPlayerSheetOpen: Boolean = false,
  val coverShapeIndex: Int = 0,
  val isShuffle: Boolean = false,
  val repeatMode: Int = 0,
  val contextMenuTrack: Track? = null,
  val libraryFilter: String = "all",
  val searchQuery: String = "",
  val recentQueries: List<String> = TestData.recentQueries,
  val settings: SettingsState = SettingsState(),
  val settingsTab: String = "look",
  val toastMessage: String? = null
)

class PlayerUiViewModel(application: Application) : AndroidViewModel(application) {
  private val playerManager = AudioPlayerManager(application)
  private val trackUriMap = mutableMapOf<Long, Uri>()

  private val database = MediatekaDatabase.getDatabase(application)
  private val repository = TrackRepository(database.trackDao())

  private val _uiState = MutableStateFlow(MediatekaUiState())
  val uiState: StateFlow<MediatekaUiState> = _uiState.asStateFlow()

  private var onlineSearchJob: Job? = null

  init {
    viewModelScope.launch {
      repository.initDefaultTracksIfEmpty(TestData.initialTracks.map { it.toEntity() })

      launch {
        repository.allTracks.collect { entities ->
          val tracksList = entities.map { entity ->
            val track = entity.toTrack()
            entity.uriString?.let { uriStr ->
              try {
                trackUriMap[entity.id] = Uri.parse(uriStr)
              } catch (_: Exception) {}
            }
            track
          }
          _uiState.update { state ->
            val updatedCurrent = tracksList.firstOrNull { it.id == state.currentTrack?.id }
              ?: state.currentTrack
              ?: tracksList.firstOrNull()
            state.copy(
              tracks = tracksList,
              currentTrack = updatedCurrent
            )
          }
        }
      }

      launch {
        playerManager.playbackState.collect { playbackState ->
          _uiState.update { currentState ->
            currentState.copy(
              isPlaying = playbackState.isPlaying,
              currentPositionSeconds = (playbackState.currentPositionMs / 1000L).toInt(),
              currentVolume = playbackState.volume,
              currentTrack = playbackState.currentTrack ?: currentState.currentTrack
            )
          }
        }
      }
    }

    // Auto-scan local device audio files into Media Library
    scanLocalAudioFiles()

    // Fetch initial online trending tracks from Audius and YouTube Music
    fetchOnlineTrending()
  }

  private fun fetchOnlineTrending() {
    viewModelScope.launch {
      try {
        val online = OnlineMusicRepository.fetchTrendingTracks()
        if (online.isNotEmpty()) {
          online.forEach { track ->
            track.coverUrl?.let { url ->
              try { trackUriMap[track.id] = Uri.parse(url) } catch (_: Exception) {}
            }
          }
          _uiState.update { state ->
            state.copy(recommendations = online + state.recommendations)
          }
        }
      } catch (_: Exception) {}
    }
  }

  fun scanLocalAudioFiles() {
    viewModelScope.launch {
      val scanned = MediaFileScanner.scanDeviceAudioFiles(getApplication())
      if (scanned.isNotEmpty()) {
        val newEntities = scanned.map { (track, uri) ->
          trackUriMap[track.id] = uri
          track.toEntity(uri.toString())
        }
        repository.insertOrUpdateAll(newEntities)
      }
    }
  }

  fun addPickedAudioFiles(uris: List<Uri>) {
    viewModelScope.launch {
      var idCounter = (System.currentTimeMillis() % 1000000) + 2000L
      val newEntities = uris.map { uri ->
        val pair = MediaFileScanner.parseUriToTrack(getApplication(), uri, idCounter++)
        trackUriMap[pair.first.id] = pair.second
        pair.first.toEntity(pair.second.toString())
      }

      if (newEntities.isNotEmpty()) {
        repository.insertOrUpdateAll(newEntities)
        showToast("Добавлено ${newEntities.size} треков")
      }
    }
  }

  fun setTab(tab: String) {
    _uiState.update { it.copy(currentTab = tab, activeArtist = null) }
  }

  fun openArtist(name: String) {
    val artist = Artist(
      id = name.lowercase().replace(" ", "_"),
      name = name,
      monthlyListeners = if (name == "Ржавый бит") "124 тыс. слушателей в месяц" else "86 тыс. слушателей в месяц",
      tracksCount = _uiState.value.tracks.count { it.artist.contains(name, ignoreCase = true) }.coerceAtLeast(4)
    )
    _uiState.update { it.copy(activeArtist = artist) }
  }

  fun closeArtist() {
    _uiState.update { it.copy(activeArtist = null) }
  }

  fun playTrack(track: Track) {
    val uri = trackUriMap[track.id]?.toString()
      ?: track.coverUrl?.takeIf { it.startsWith("http") }
      ?: track.coverUrl
    playerManager.playTrack(track, uri)
    _uiState.update {
      it.copy(
        currentTrack = track,
        isPlaying = true
      )
    }
  }

  fun togglePlayPause() {
    playerManager.togglePlayPause()
  }

  fun playNext(track: Track) {
    _uiState.update { state ->
      state.copy(queue = listOf(track) + state.queue)
    }
    showToast("Сыграет следующим")
  }

  fun addToQueue(track: Track) {
    _uiState.update { state ->
      state.copy(queue = state.queue + track)
    }
    showToast("Добавлено в очередь")
  }

  fun nextTrack() {
    val state = _uiState.value
    if (state.queue.isNotEmpty()) {
      val next = state.queue.first()
      _uiState.update { it.copy(queue = it.queue.drop(1)) }
      playTrack(next)
      return
    }

    val current = state.currentTrack ?: return
    val allPlayable = state.tracks + state.recommendations + state.onlineSearchResults
    val currentIndex = allPlayable.indexOfFirst { it.id == current.id }
    val nextIndex = if (currentIndex >= 0 && currentIndex < allPlayable.size - 1) {
      currentIndex + 1
    } else {
      0
    }
    val nextTrack = if (allPlayable.isNotEmpty()) allPlayable[nextIndex] else current
    playTrack(nextTrack)
  }

  fun previousTrack() {
    val state = _uiState.value
    val current = state.currentTrack ?: return
    val allPlayable = state.tracks + state.recommendations + state.onlineSearchResults
    val currentIndex = allPlayable.indexOfFirst { it.id == current.id }
    val prevIndex = if (currentIndex > 0) {
      currentIndex - 1
    } else {
      (allPlayable.size - 1).coerceAtLeast(0)
    }
    val prevTrack = if (allPlayable.isNotEmpty()) allPlayable[prevIndex] else current
    playTrack(prevTrack)
  }

  fun seekTo(seconds: Int) {
    playerManager.seekToMs(seconds * 1000L)
  }

  fun setVolume(volume: Float) {
    playerManager.setVolume(volume)
  }

  fun toggleFavorite(trackId: Long) {
    viewModelScope.launch {
      val track = _uiState.value.tracks.firstOrNull { it.id == trackId }
        ?: _uiState.value.recommendations.firstOrNull { it.id == trackId }
        ?: _uiState.value.onlineSearchResults.firstOrNull { it.id == trackId }
        ?: return@launch
      repository.toggleFavorite(trackId, !track.isFavorite)
    }
  }

  fun downloadTrack(track: Track) {
    viewModelScope.launch {
      repository.setDownloaded(track.id, true)
      showToast("Загружено в раздел «Загрузки»")
    }
  }

  fun deleteTrack(track: Track) {
    viewModelScope.launch {
      repository.deleteTrack(track.id)
      showToast("Удалено из медиатеки")
    }
  }

  fun toggleShuffle() {
    _uiState.update { it.copy(isShuffle = !it.isShuffle) }
  }

  fun cycleRepeat() {
    _uiState.update { it.copy(repeatMode = (it.repeatMode + 1) % 3) }
  }

  fun cycleCoverShape() {
    _uiState.update { it.copy(coverShapeIndex = (it.coverShapeIndex + 1) % 3) }
  }

  fun openPlayerSheet() {
    _uiState.update { it.copy(isPlayerSheetOpen = true) }
  }

  fun closePlayerSheet() {
    _uiState.update { it.copy(isPlayerSheetOpen = false) }
  }

  fun openContextMenu(track: Track) {
    _uiState.update { it.copy(contextMenuTrack = track) }
  }

  fun closeContextMenu() {
    _uiState.update { it.copy(contextMenuTrack = null) }
  }

  fun setSearchQuery(query: String) {
    _uiState.update { it.copy(searchQuery = query) }
    onlineSearchJob?.cancel()
    if (query.trim().length >= 2) {
      _uiState.update { it.copy(isSearchingOnline = true) }
      onlineSearchJob = viewModelScope.launch {
        delay(300)
        val online = OnlineMusicRepository.searchOnlineTracks(query)
        online.forEach { track ->
          track.coverUrl?.let { url ->
            try { trackUriMap[track.id] = Uri.parse(url) } catch (_: Exception) {}
          }
        }
        _uiState.update { it.copy(onlineSearchResults = online, isSearchingOnline = false) }
      }
    } else {
      _uiState.update { it.copy(onlineSearchResults = emptyList(), isSearchingOnline = false) }
    }
  }

  fun clearRecentQueries() {
    _uiState.update { it.copy(recentQueries = emptyList()) }
  }

  fun setLibraryFilter(filter: String) {
    _uiState.update { it.copy(libraryFilter = filter) }
  }

  fun setSettingsTab(tab: String) {
    _uiState.update { it.copy(settingsTab = tab) }
  }

  fun setTheme(themeId: String) {
    _uiState.update { it.copy(settings = it.settings.copy(themeId = themeId)) }
  }

  fun setGlassStyle(style: String) {
    _uiState.update { it.copy(settings = it.settings.copy(glassStyle = style)) }
  }

  fun toggleSnow() {
    _uiState.update { it.copy(settings = it.settings.copy(snowEnabled = !it.settings.snowEnabled)) }
  }

  fun setSnowAmount(amount: Int) {
    _uiState.update { it.copy(settings = it.settings.copy(snowAmount = amount)) }
  }

  fun setFavIcon(icon: String) {
    _uiState.update { it.copy(settings = it.settings.copy(favIcon = icon)) }
  }

  fun toggleVibration() {
    _uiState.update { it.copy(settings = it.settings.copy(vibrationEnabled = !it.settings.vibrationEnabled)) }
  }

  fun toggleAnimations() {
    _uiState.update { it.copy(settings = it.settings.copy(alwaysAnimations = !it.settings.alwaysAnimations)) }
  }

  fun setBgType(type: String) {
    _uiState.update { it.copy(settings = it.settings.copy(bgType = type)) }
  }

  fun toggleBgColorByCover() {
    _uiState.update { it.copy(settings = it.settings.copy(bgColorByCover = !it.settings.bgColorByCover)) }
  }

  fun toggleBgMoveOnlyPlaying() {
    _uiState.update { it.copy(settings = it.settings.copy(bgMoveOnlyWhilePlaying = !it.settings.bgMoveOnlyWhilePlaying)) }
  }

  fun setBgSpeed(speed: Int) {
    _uiState.update { it.copy(settings = it.settings.copy(bgSpeed = speed)) }
  }

  fun setBgIntensity(intensity: Int) {
    _uiState.update { it.copy(settings = it.settings.copy(bgIntensity = intensity)) }
  }

  fun setFeedLanguage(lang: String) {
    _uiState.update { it.copy(settings = it.settings.copy(feedLanguage = lang)) }
  }

  fun addMyArtist(name: String) {
    if (name.isBlank()) return
    _uiState.update {
      it.copy(settings = it.settings.copy(myArtists = it.settings.myArtists + name.trim()))
    }
  }

  fun removeMyArtist(name: String) {
    _uiState.update {
      it.copy(settings = it.settings.copy(myArtists = it.settings.myArtists - name))
    }
  }

  fun setTracksPerArtist(count: Int) {
    _uiState.update { it.copy(settings = it.settings.copy(tracksPerArtist = count)) }
  }

  fun setFeedSize(size: Int) {
    _uiState.update { it.copy(settings = it.settings.copy(feedSize = size)) }
  }

  fun toggleFeedAutoPlay() {
    _uiState.update { it.copy(settings = it.settings.copy(feedAutoPlay = !it.settings.feedAutoPlay)) }
  }

  fun toggleFeedAutoScroll() {
    _uiState.update { it.copy(settings = it.settings.copy(feedAutoScroll = !it.settings.feedAutoScroll)) }
  }

  fun setDownloadDestination(dest: String) {
    _uiState.update { it.copy(settings = it.settings.copy(downloadDestination = dest)) }
  }

  fun showToast(message: String) {
    _uiState.update { it.copy(toastMessage = message) }
  }

  fun clearToast() {
    _uiState.update { it.copy(toastMessage = null) }
  }

  override fun onCleared() {
    playerManager.release()
    super.onCleared()
  }
}
